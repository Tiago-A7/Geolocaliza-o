<?php
/**
 * @file dashboard.php
 * @brief Página principal do sistema com mapa interativo.
 * 
 * Esta página apresenta o mapa Leaflet com funcionalidades completas
 * de visualização, inserção e gestão de locais georreferenciados.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

require_once __DIR__ . '/includes/auth.php';
requerAutenticacao();

require_once __DIR__ . '/includes/functions.php';

/** @var array $categorias Lista de categorias para o formulário */
$categorias = getCategorias();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Mapa Interativo</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
    
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <?php include 'templates/menu.php'; ?>
        
        <!-- Conteúdo Principal -->
        <div id="content">
            <!-- Barra Superior -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapseDesktop" class="btn btn-info d-none d-md-block">
                        <i class="bi bi-list"></i>
                    </button>
                    <span class="navbar-text ms-auto">
                        Bem-vindo, <strong><?= sanitizar($_SESSION['nome']) ?></strong>
                        <?php if (ehAdmin()): ?>
                            <span class="badge bg-danger">Admin</span>
                        <?php else: ?>
                            <span class="badge bg-primary">Utilizador</span>
                        <?php endif; ?>
                    </span>
                </div>
            </nav>

            <!-- Área do Mapa -->
            <div class="container-fluid p-0">
                <div id="map"></div>
                
                <!-- Botões de Controlo do Mapa -->
                <div class="map-controls" style="margin-top: 10rem;">
                    <button class="btn btn-primary mb-2" onclick="abrirFormularioNovo()">
                        <i class="bi bi-plus-lg"></i> Novo Local
                    </button>
                    <button class="btn btn-secondary mb-2" onclick="localizarUtilizador()">
                        <i class="bi bi-geo"></i> Minha Localização
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Formulário -->
    <div class="modal fade" id="modalLocal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-geo-alt-fill"></i> <span id="modalTitulo">Novo Local</span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="formLocal" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="localId">
                        <input type="hidden" name="latitude" id="latInput">
                        <input type="hidden" name="longitude" id="lngInput">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nome *</label>
                                <input type="text" name="nome" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Categoria *</label>
                                <select name="categoria_id" class="form-select" required>
                                    <?php foreach ($categorias as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= sanitizar($cat['nome']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">País *</label>
                                <input type="text" name="pais" id="paisInput" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Cidade *</label>
                                <input type="text" name="cidade" id="cidadeInput" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Morada</label>
                            <input type="text" name="morada" id="moradaInput" class="form-control">
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Telefone</label>
                                <input type="tel" name="telefone" class="form-control">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Descrição</label>
                            <textarea name="descricao" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Fotografia (máx. 2MB)</label>
                            <input type="file" name="foto" class="form-control" accept="image/*">
                            <div id="previewFoto" class="mt-2"></div>
                        </div>
                        
                        <div class="mb-3" id="coordenadasDisplay">
                            <small class="text-muted">
                                <i class="bi bi-geo"></i> 
                                Lat: <span id="latDisplay">0</span>, 
                                Lng: <span id="lngDisplay">0</span>
                            </small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" onclick="guardarLocal()">
                        <i class="bi bi-check-lg"></i> Guardar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Envio por Email -->
    <div class="modal fade" id="modalEmail" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-envelope"></i> Enviar por Email</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="formEmail">
                        <input type="hidden" id="emailLocalId">
                        <div class="mb-3">
                            <label class="form-label">Email do Destinatário *</label>
                            <input type="email" name="email_destino" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mensagem Adicional</label>
                            <textarea name="mensagem" class="form-control" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" onclick="enviarEmail()">
                        <i class="bi bi-send"></i> Enviar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
    <script src="js/app.js"></script>
</body>
</html>