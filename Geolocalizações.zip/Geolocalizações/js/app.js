/**
 * @file app.js
 * @brief Lógica principal do mapa interativo e funcionalidades AJAX.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

/**
 * @var {L.Map} map Instância principal do mapa Leaflet
 */
let map;

/**
 * @var {L.MarkerClusterGroup} markers Grupo de marcadores com clustering
 */
let markers;

/**
 * @var {Object} cacheNominatim Cache para resultados de geocodificação
 */
const cacheNominatim = {};

/**
 * @var {boolean} isAdmin Flag indicando se o utilizador é administrador
 */
const isAdmin = document.querySelector('.badge.bg-danger') !== null;

/**
 * @var {string} API_BASE URL base para as APIs
 */
const API_BASE = 'api/';

/**
 * @brief Obtém o ID do utilizador atual da sessão (do DOM).
 * 
 * Tenta obter de um elemento data-user-id ou do atributo data do body.
 * 
 * @return {number|null} ID do utilizador ou null se não encontrado
 */
function getUserId() {
    // Tenta obter de elemento específico
    const userElement = document.getElementById('current-user-id');
    if (userElement && userElement.value) {
        return parseInt(userElement.value, 10);
    }
    
    // Tenta obter do body data attribute
    const body = document.body;
    if (body.dataset.userId) {
        return parseInt(body.dataset.userId, 10);
    }
    
    // Tenta obter de meta tag
    const metaUser = document.querySelector('meta[name="user-id"]');
    if (metaUser) {
        return parseInt(metaUser.content, 10);
    }
    
    // Fallback: tenta extrair do HTML do badge do utilizador
    const navbarText = document.querySelector('.navbar-text');
    if (navbarText) {
        // Assume que o último recurso é verificar se pode editar tudo (admin)
        return isAdmin ? 0 : null; // 0 para admin (pode editar tudo)
    }
    
    console.warn('getUserId: Não foi possível determinar ID do utilizador');
    return null;
}

/**
 * @brief Inicialização quando o DOM está pronto
 */
document.addEventListener('DOMContentLoaded', function() {
    // Verifica se estamos na página do mapa
    if (document.getElementById('map')) {
        inicializarMapa();
    }
    configurarSidebar();
    configurarFormulario();
});

/**
 * @brief Inicializa o mapa Leaflet com todas as configurações.
 * 
 * @return {void}
 */
function inicializarMapa() {
    // Camadas base disponíveis
    const camadasBase = {
        "OpenStreetMap": L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }),
        "Satélite": L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri'
        }),
        "Terreno": L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenTopoMap'
        })
    };

    // Criação do mapa
    map = L.map('map', {
        center: [39.5, -8],
        zoom: 6,
        layers: [camadasBase["OpenStreetMap"]],
        zoomControl: false
    });

    // Adiciona controles
    L.control.zoom({ position: 'topright' }).addTo(map);
    L.control.scale({ metric: true, imperial: false }).addTo(map);
    L.control.layers(camadasBase, {}, { position: 'topright' }).addTo(map);

    // Inicializa grupo de marcadores com clustering
    markers = L.markerClusterGroup({
        chunkedLoading: true,
        spiderfyOnMaxZoom: true,
        showCoverageOnHover: true,
        zoomToBoundsOnClick: true
    });

    map.addLayer(markers);

    // Carrega locais existentes
    carregarLocais();

    // Cria legenda
    criarLegenda();

    // Evento de clique no mapa para novo local
    map.on('click', function(e) {
        abrirFormularioNovo(e.latlng);
    });
}

/**
 * @brief Carrega locais da API com tratamento de erros detalhado.
 * 
 * @return {Promise<void>}
 */
async function carregarLocais() {
    try {
        console.log("A carregar locais de:", API_BASE + 'locais.php');
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
        
        const resposta = await fetch('locais.php', {
            signal: controller.signal,
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        clearTimeout(timeoutId);
        
        console.log("Resposta HTTP:", resposta.status, resposta.statusText);
        
        if (!resposta.ok) {
            throw new Error(`HTTP ${resposta.status}: ${resposta.statusText}`);
        }
        
        // Verifica se a resposta é realmente JSON
        const contentType = resposta.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const texto = await resposta.text();
            console.error("Resposta não-JSON recebida:", texto.substring(0, 500));
            throw new Error('Resposta inválida do servidor (não é JSON)');
        }
        
        const locais = await resposta.json();
        console.log("Locais carregados:", locais.length);
        
        // Limpa marcadores existentes
        markers.clearLayers();
        
        // Conjunto para rastrear categorias únicas na legenda
        const categoriasNaLegenda = new Set();
        
        if (!Array.isArray(locais)) {
            console.error("Resposta não é array:", locais);
            if (locais.status === 'erro') {
                throw new Error(locais.mensagem || 'Erro no servidor');
            }
            throw new Error('Formato de dados inválido');
        }
        
        locais.forEach(local => {
            if (!local.latitude || !local.longitude) {
                console.warn("Local sem coordenadas:", local);
                return;
            }
            
            // Cria ícone personalizado
            const icone = criarIcone(local.cor || '#4e73df', local.letras || 'LOC');
            
            // Cria marcador
            const marker = L.marker([local.latitude, local.longitude], { icon: icone });
            
            // Cria conteúdo do popup
            const popupContent = criarPopupContent(local);
            marker.bindPopup(popupContent);
            
            // Adiciona ao grupo
            markers.addLayer(marker);

            // Atualiza legenda se categoria nova
            if (local.categoria_id && !categoriasNaLegenda.has(local.categoria_id)) {
                atualizarLegenda(local);
                categoriasNaLegenda.add(local.categoria_id);
            }
        });
        
    } catch (erro) {
        console.error('Erro detalhado ao carregar locais:', erro);
        
        let mensagem = 'Erro ao carregar locais';
        if (erro.name === 'AbortError') {
            mensagem = 'Timeout: Servidor não respondeu a tempo';
        } else if (erro.message.includes('Failed to fetch')) {
            mensagem = 'Erro de rede: Verifique sua conexão ou se o arquivo api/locais.php existe';
        } else {
            mensagem = erro.message;
        }
        
        mostrarNotificacao(mensagem, 'danger');
    }
}

/**
 * @brief Cria um ícone SVG personalizado para marcadores.
 * 
 * @param {string} cor Cor hexadecimal do marcador
 * @param {string} letras Letras a exibir no marcador
 * @return {L.DivIcon} Ícone Leaflet personalizado
 */
function criarIcone(cor, letras) {
    return L.divIcon({
        className: 'custom-marker',
        html: `
            <div class="leaflet-marker-drop">
                <svg viewBox="0 0 30 42" width="30" height="42">
                    <path d="M15 0 C23 0 30 7 30 15 C30 23 15 42 15 42 C15 42 0 23 0 15 C0 7 7 0 15 0 Z" 
                          fill="${cor}" stroke="#fff" stroke-width="2"/>
                </svg>
                <div class="marker-label">${letras}</div>
            </div>
        `,
        iconSize: [30, 42],
        iconAnchor: [15, 42],
        popupAnchor: [0, -42]
    });
}

/**
 * @brief Cria o HTML do popup para um local.
 * 
 * @param {Object} local Dados do local da base de dados
 * @return {string} HTML formatado do popup
 */
function criarPopupContent(local) {
    // CORREÇÃO: Verifica permissão usando getUserId()
    const userId = getUserId();
    const podeEditar = isAdmin || (userId !== null && local.criado_por == userId);
    
    let html = `<div class="local-popup"><h5>${escapeHtml(local.nome)}</h5>`;
    
    // Adiciona foto se existir
    if (local.foto) {
        html += `<img src="uploads/fotos/${escapeHtml(local.foto)}" class="foto-preview" alt="Foto">`;
    }

    html += `
        <div class="info-row"><span class="info-label">Categoria:</span> ${escapeHtml(local.categoria)}</div>
        <div class="info-row"><span class="info-label">Localização:</span> ${escapeHtml(local.cidade)}, ${escapeHtml(local.pais)}</div>
    `;

    if (local.morada) {
        html += `<div class="info-row"><span class="info-label">Morada:</span> ${escapeHtml(local.morada)}</div>`;
    }
    
    if (local.telefone) {
        html += `<div class="info-row"><span class="info-label">Tel:</span> ${escapeHtml(local.telefone)}</div>`;
    }
    
    if (local.email) {
        html += `<div class="info-row"><span class="info-label">Email:</span> ${escapeHtml(local.email)}</div>`;
    }
    
    if (local.descricao) {
        html += `<div class="info-row"><span class="info-label">Descrição:</span> ${escapeHtml(local.descricao)}</div>`;
    }
    
    html += `<div class="info-row"><small class="text-muted">Por: ${escapeHtml(local.autor || 'Desconhecido')}</small></div>`;

    // Botões de ação
    html += `<div class="actions">`;
    
    html += `
        <button class="btn btn-sm btn-outline-primary btn-icon" onclick="abrirEmailModal(${local.id})" title="Enviar por email">
            <i class="bi bi-envelope"></i>
        </button>
    `;

    if (podeEditar) {
        html += `
            <button class="btn btn-sm btn-outline-warning btn-icon" onclick="editarLocal(${local.id})" title="Editar">
                <i class="bi bi-pencil"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger btn-icon" onclick="apagarLocal(${local.id})" title="Apagar">
                <i class="bi bi-trash"></i>
            </button>
        `;
    }
    
    html += `</div></div>`;
    
    return html;
}

/**
 * @brief Cria o controle de legenda no mapa.
 * 
 * @return {void}
 */
function criarLegenda() {
    const legenda = L.control({ position: 'bottomright' });
    
    legenda.onAdd = function() {
        const div = L.DomUtil.create('div', 'legenda');
        div.innerHTML = '<h6><i class="bi bi-list-ul"></i> Legenda</h6>';
        div.id = 'legenda-container';
        return div;
    };
    
    legenda.addTo(map);
}

/**
 * @brief Adiciona item à legenda do mapa.
 * 
 * @param {Object} local Dados do local com categoria
 * @return {void}
 */
function atualizarLegenda(local) {
    const container = document.getElementById('legenda-container');
    if (!container) return;
    
    const item = document.createElement('div');
    item.className = 'legenda-item';
    item.innerHTML = `
        <span class="legenda-cor" style="background: ${local.cor}"></span>
        <span>${escapeHtml(local.categoria)}</span>
    `;
    container.appendChild(item);
}

/**
 * @brief Abre o formulário para criar novo local.
 * 
 * @param {L.LatLng} [latlng] Coordenadas opcionais pré-preenchidas
 * @return {void}
 */
function abrirFormularioNovo(latlng) {
    const form = document.getElementById('formLocal');
    if (!form) {
        console.error('Formulário formLocal não encontrado');
        return;
    }
    
    form.reset();
    document.getElementById('localId').value = '';
    document.getElementById('modalTitulo').textContent = 'Novo Local';
    const previewFoto = document.getElementById('previewFoto');
    if (previewFoto) previewFoto.innerHTML = '';
    
    if (latlng) {
        document.getElementById('latInput').value = latlng.lat;
        document.getElementById('lngInput').value = latlng.lng;
        document.getElementById('latDisplay').textContent = latlng.lat.toFixed(6);
        document.getElementById('lngDisplay').textContent = latlng.lng.toFixed(6);
        
        // Consulta Nominatim para preencher endereço
        consultarNominatim(latlng.lat, latlng.lng);
    }
    
    const modalEl = document.getElementById('modalLocal');
    if (modalEl) {
        const modal = new bootstrap.Modal(modalEl);
        modal.show();
    }
}

/**
 * @brief Consulta serviço Nominatim para reverse geocoding.
 * 
 * @param {number} lat Latitude
 * @param {number} lng Longitude
 * @return {Promise<void>}
 */
async function consultarNominatim(lat, lng) {
    const chave = `${lat.toFixed(5)},${lng.toFixed(5)}`;
    
    // Verifica cache
    if (cacheNominatim[chave]) {
        preencherEndereco(cacheNominatim[chave]);
        return;
    }
    
    try {
        const resposta = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=pt`,
            { headers: { 'User-Agent': 'GeoLocApp/1.0' } }
        );
        
        if (!resposta.ok) throw new Error('Erro na consulta');
        
        const dados = await resposta.json();
        cacheNominatim[chave] = dados.address || {};
        preencherEndereco(cacheNominatim[chave]);
        
    } catch (erro) {
        console.warn('Nominatim indisponível:', erro);
    }
}

/**
 * @brief Preenche campos de endereço com dados do Nominatim.
 * 
 * @param {Object} address Dados de endereço do Nominatim
 * @return {void}
 */
function preencherEndereco(address) {
    const paisInput = document.getElementById('paisInput');
    const cidadeInput = document.getElementById('cidadeInput');
    const moradaInput = document.getElementById('moradaInput');
    
    if (paisInput) paisInput.value = address.country || '';
    if (cidadeInput) cidadeInput.value = address.city || address.town || address.village || address.municipality || '';
    if (moradaInput) moradaInput.value = [address.road, address.house_number].filter(Boolean).join(', ');
}

/**
 * @brief Guarda o local (criar ou atualizar).
 * 
 * @return {Promise<void>}
 */
async function guardarLocal() {
    const form = document.getElementById('formLocal');
    if (!form) {
        mostrarNotificacao('Erro: Formulário não encontrado', 'danger');
        return;
    }
    
    const formData = new FormData(form);
    
    // Validação cliente
    if (!formData.get('nome') || !formData.get('pais') || !formData.get('cidade')) {
        mostrarNotificacao('Preencha os campos obrigatórios (Nome, País, Cidade)', 'warning');
        return;
    }
    
    const lat = parseFloat(formData.get('latitude'));
    const lng = parseFloat(formData.get('longitude'));
    if (!lat || !lng) {
        mostrarNotificacao('Clique no mapa para definir a localização', 'warning');
        return;
    }
    
    console.log("A enviar dados:", Object.fromEntries(formData));
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s para upload
        
        const resposta = await fetch('locais.php', {
            method: 'POST',
            body: formData,
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        console.log("Resposta guardar:", resposta.status);
        
        // Verifica se resposta é JSON
        const contentType = resposta.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const texto = await resposta.text();
            console.error("Resposta não-JSON:", texto.substring(0, 500));
            throw new Error('Erro no servidor: resposta inválida');
        }
        
        const resultado = await resposta.json();
        console.log("Resultado:", resultado);
        
        if (resultado.status === 'ok') {
            mostrarNotificacao(resultado.mensagem || 'Guardado com sucesso!', 'success');
            const modalEl = document.getElementById('modalLocal');
            if (modalEl) {
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();
            }
            carregarLocais();
        } else {
            mostrarNotificacao(resultado.mensagem || 'Erro ao guardar', 'danger');
        }
        
    } catch (erro) {
        console.error('Erro detalhado ao guardar:', erro);
        
        let mensagem = 'Erro de comunicação';
        if (erro.name === 'AbortError') {
            mensagem = 'Timeout: A operação demorou muito tempo';
        } else if (erro.message.includes('Failed to fetch')) {
            mensagem = 'Erro de rede: Não foi possível contactar o servidor';
        } else {
            mensagem = erro.message;
        }
        
        mostrarNotificacao(mensagem, 'danger');
    }
}

/**
 * @brief Carrega dados de um local para edição.
 * 
 * @param {number} id ID do local a editar
 * @return {Promise<void>}
 */
async function editarLocal(id) {
    try {
        const resposta = await fetch(`locais.php?id=${id}`);
        
        if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
        
        const local = await resposta.json();
        
        if (local.status === 'erro') {
            mostrarNotificacao(local.mensagem, 'danger');
            return;
        }
        
        // Preenche formulário
        document.getElementById('localId').value = local.id;
        document.getElementById('modalTitulo').textContent = 'Editar Local';
        
        const form = document.getElementById('formLocal');
        form.nome.value = local.nome || '';
        form.categoria_id.value = local.categoria_id || '';
        form.pais.value = local.pais || '';
        form.cidade.value = local.cidade || '';
        form.morada.value = local.morada || '';
        form.telefone.value = local.telefone || '';
        form.email.value = local.email || '';
        form.descricao.value = local.descricao || '';
        form.latitude.value = local.latitude || '';
        form.longitude.value = local.longitude || '';
        
        document.getElementById('latDisplay').textContent = local.latitude || '0';
        document.getElementById('lngDisplay').textContent = local.longitude || '0';
        
        const previewFoto = document.getElementById('previewFoto');
        if (previewFoto) {
            if (local.foto) {
                previewFoto.innerHTML = `<img src="uploads/fotos/${local.foto}" class="img-thumbnail" style="max-height: 100px;">`;
            } else {
                previewFoto.innerHTML = '';
            }
        }
        
        const modalEl = document.getElementById('modalLocal');
        if (modalEl) {
            const modal = new bootstrap.Modal(modalEl);
            modal.show();
        }
        
    } catch (erro) {
        console.error('Erro ao carregar local:', erro);
        mostrarNotificacao('Erro ao carregar dados do local', 'danger');
    }
}

/**
 * @brief Apaga um local após confirmação.
 * 
 * @param {number} id ID do local a apagar
 * @return {Promise<void>}
 */
async function apagarLocal(id) {
    if (!confirm('Tem certeza que deseja apagar este local?')) return;
    
    try {
        const resposta = await fetch(`locais.php?id=${id}`, {
            method: 'DELETE'
        });
        
        const resultado = await resposta.json();
        
        if (resultado.status === 'ok') {
            mostrarNotificacao('Local apagado com sucesso', 'success');
            carregarLocais();
        } else {
            mostrarNotificacao(resultado.mensagem || 'Erro ao apagar', 'danger');
        }
        
    } catch (erro) {
        console.error('Erro ao apagar:', erro);
        mostrarNotificacao('Erro de comunicação ao apagar', 'danger');
    }
}

/**
 * @brief Abre modal para envio de email.
 * 
 * @param {number} localId ID do local a enviar
 * @return {void}
 */
function abrirEmailModal(localId) {
    const emailLocalId = document.getElementById('emailLocalId');
    const formEmail = document.getElementById('formEmail');
    
    if (emailLocalId) emailLocalId.value = localId;
    if (formEmail) formEmail.reset();
    
    const modalEl = document.getElementById('modalEmail');
    if (modalEl) {
        const modal = new bootstrap.Modal(modalEl);
        modal.show();
    }
}

/**
 * @brief Envia informação do local por email.
 * 
 * @return {Promise<void>}
 */
async function enviarEmail() {
    const localId = document.getElementById('emailLocalId')?.value;
    const form = document.getElementById('formEmail');
    
    if (!form) return;
    
    const formData = new FormData(form);
    formData.append('local_id', localId);
    
    try {
        const resposta = await fetch('email.php', {
            method: 'POST',
            body: formData
        });
        
        const resultado = await resposta.json();
        
        if (resultado.status === 'ok') {
            mostrarNotificacao('Email enviado com sucesso!', 'success');
            const modalEl = document.getElementById('modalEmail');
            if (modalEl) {
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();
            }
        } else {
            mostrarNotificacao(resultado.mensagem || 'Erro ao enviar', 'danger');
        }
        
    } catch (erro) {
        console.error('Erro ao enviar email:', erro);
        mostrarNotificacao('Erro de comunicação', 'danger');
    }
}

/**
 * @brief Localiza o utilizador via Geolocation API.
 * 
 * @return {void}
 */
function localizarUtilizador() {
    if (!navigator.geolocation) {
        mostrarNotificacao('Geolocalização não suportada', 'warning');
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        (posicao) => {
            const { latitude, longitude } = posicao.coords;
            map.setView([latitude, longitude], 15);
            L.marker([latitude, longitude]).addTo(map).bindPopup('Sua localização').openPopup();
        },
        (erro) => {
            mostrarNotificacao('Não foi possível obter localização: ' + erro.message, 'warning');
        }
    );
}

/**
 * @brief Configura comportamento da sidebar responsiva.
 * 
 * @return {void}
 */
function configurarSidebar() {
    const sidebar = document.getElementById('sidebar');
    const toggleDesktop = document.getElementById('sidebarCollapseDesktop');
    const toggleMobile = document.getElementById('sidebarCollapse');
    
    if (!sidebar) return;
    
    function toggleSidebar() {
        sidebar.classList.toggle('active');
    }
    
    if (toggleDesktop) toggleDesktop.addEventListener('click', toggleSidebar);
    if (toggleMobile) toggleMobile.addEventListener('click', toggleSidebar);
}

/**
 * @brief Configura eventos do formulário.
 * 
 * @return {void}
 */
function configurarFormulario() {
    // Preview de imagem antes do upload
    const inputFoto = document.querySelector('input[name="foto"]');
    if (inputFoto) {
        inputFoto.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            if (file.size > 2 * 1024 * 1024) {
                mostrarNotificacao('Imagem deve ter menos de 2MB', 'warning');
                this.value = '';
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const previewFoto = document.getElementById('previewFoto');
                if (previewFoto) {
                    previewFoto.innerHTML = `<img src="${e.target.result}" class="img-thumbnail" style="max-height: 100px;">`;
                }
            };
            reader.readAsDataURL(file);
        });
    }
}

/**
 * @brief Mostra notificação toast.
 * 
 * @param {string} mensagem Texto a exibir
 * @param {string} tipo Tipo: success, danger, warning, info
 * @return {void}
 */
function mostrarNotificacao(mensagem, tipo = 'info') {
    // Remove notificações antigas
    const notificacoesAntigas = document.querySelectorAll('.alert.position-fixed');
    notificacoesAntigas.forEach(el => el.remove());
    
    const toast = document.createElement('div');
    toast.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px; max-width: 500px;';
    
    const icones = {
        success: 'check-circle',
        danger: 'exclamation-triangle',
        warning: 'exclamation-circle',
        info: 'info-circle'
    };
    
    toast.innerHTML = `
        <i class="bi bi-${icones[tipo] || 'info-circle'} me-2"></i>
        ${mensagem}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(toast);
    
    // Auto-remove após 5 segundos
    setTimeout(() => {
        if (toast.parentNode) {
            const bsAlert = bootstrap.Alert.getInstance(toast);
            if (bsAlert) {
                bsAlert.close();
            } else {
                toast.remove();
            }
        }
    }, 5000);
}

/**
 * @brief Escapa HTML para prevenir XSS.
 * 
 * @param {string} text Texto potencialmente perigoso
 * @return {string} Texto escapado
 */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}