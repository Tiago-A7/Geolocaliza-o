<?php
/**
 * @file pesquisa.php
 * @brief Interface de pesquisa avançada com filtros e paginação.
 * 
 * Permite pesquisar locais por país, cidade e categoria,
 * com suporte a paginação de resultados.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

require_once __DIR__ . '/includes/auth.php';
requerAutenticacao();
require_once __DIR__ . '/includes/functions.php';

/** @var array $categorias Lista de categorias para filtro */
$categorias = getCategorias();

/** @var string $filtro_pais Filtro de país */
$filtro_pais = $_GET['pais'] ?? '';

/** @var string $filtro_cidade Filtro de cidade */
$filtro_cidade = $_GET['cidade'] ?? '';

/** @var int $filtro_categoria Filtro de categoria */
$filtro_categoria = (int)($_GET['categoria'] ?? 0);

/** @var int $pagina Página atual */
$pagina = (int)($_GET['pagina'] ?? 1);

/** @var int $por_pagina Itens por página */
$por_pagina = 10;

// Constrói query de pesquisa
$params = [];
$where = ['l.ativo = 1'];

if ($filtro_pais) {
    $where[] = 'l.pais LIKE :pais';
    $params[':pais'] = "%$filtro_pais%";
}

if ($filtro_cidade) {
    $where[] = 'l.cidade LIKE :cidade';
    $params[':cidade'] = "%$filtro_cidade%";
}

if ($filtro_categoria) {
    $where[] = 'l.categoria_id = :categoria';
    $params[':categoria'] = $filtro_categoria;
}

$where_sql = implode(' AND ', $where);

// Conta total de resultados
$stmt = $pdo->prepare("SELECT COUNT(*) FROM locais l WHERE $where_sql");
$stmt->execute($params);
$total = $stmt->fetchColumn();

// Paginação
$pagination = paginar($total, $pagina, $por_pagina);

// Busca resultados
$sql = "
    SELECT 
        l.*,
        c.nome as categoria,
        c.cor,
        u.nome as autor
    FROM locais l
    JOIN categorias c ON l.categoria_id = c.id
    JOIN utilizadores u ON l.criado_por = u.id
    WHERE $where_sql
    ORDER BY l.id DESC
    LIMIT {$pagination['inicio']}, {$pagination['limite']}
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$locais = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Pesquisa Avançada</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <?php include 'templates/menu.php'; ?>
        
        <div id="content">
            <div class="container-fluid p-4">
                <h2><i class="bi bi-search"></i> Pesquisa Avançada</h2>
                
                <!-- Formulário de Filtros -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">País</label>
                                <input type="text" name="pais" class="form-control" 
                                       value="<?= sanitizar($filtro_pais) ?>" placeholder="Ex: Portugal">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Cidade</label>
                                <input type="text" name="cidade" class="form-control" 
                                       value="<?= sanitizar($filtro_cidade) ?>" placeholder="Ex: Lisboa">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Categoria</label>
                                <select name="categoria" class="form-select">
                                    <option value="">Todas</option>
                                    <?php foreach ($categorias as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" 
                                        <?= $filtro_categoria == $cat['id'] ? 'selected' : '' ?>>
                                        <?= sanitizar($cat['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Pesquisar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Resultados -->
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0"><?= $total ?> resultado(s) encontrado(s)</h5>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Foto</th>
                                        <th>Nome</th>
                                        <th>Categoria</th>
                                        <th>Localização</th>
                                        <th>Autor</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($locais as $local): ?>
                                    <tr>
                                        <td>
                                            <?php if ($local['foto']): ?>
                                            <img src="uploads/fotos/<?= $local['foto'] ?>" 
                                                 class="rounded" width="50" height="50" style="object-fit: cover;">
                                            <?php else: ?>
                                            <div class="bg-secondary rounded" style="width:50px;height:50px;"></div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= sanitizar($local['nome']) ?></td>
                                        <td>
                                            <span class="badge" style="background: <?= $local['cor'] ?>">
                                                <?= sanitizar($local['categoria']) ?>
                                            </span>
                                        </td>
                                        <td><?= sanitizar($local['cidade']) ?>, <?= sanitizar($local['pais']) ?></td>
                                        <td><?= sanitizar($local['autor']) ?></td>
                                        <td>
                                            <a href="dashboard.php?local=<?= $local['id'] ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-geo-alt"></i> Ver no Mapa
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Paginação -->
                        <?php if ($pagination['total_paginas'] > 1): ?>
                        <nav aria-label="Paginação">
                            <ul class="pagination">
                                <?php if ($pagination['pagina_atual'] > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $pagination['pagina_atual'] - 1])) ?>">
                                        <i class="bi bi-chevron-left"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $pagination['total_paginas']; $i++): ?>
                                <li class="page-item <?= $i == $pagination['pagina_atual'] ? 'active' : '' ?>">
                                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $i])) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                                <?php endfor; ?>
                                
                                <?php if ($pagination['pagina_atual'] < $pagination['total_paginas']): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $pagination['pagina_atual'] + 1])) ?>">
                                        <i class="bi bi-chevron-right"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app.js"></script>
</body>
</html>