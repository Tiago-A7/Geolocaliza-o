<?php
/**
 * @file menu.php
 * @brief Menu lateral de navegação responsivo.
 * 
 * Template de menu lateral colapsável com todas as funcionalidades
 * do sistema, adaptado de template profissional.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @note Requer Bootstrap 5 e Bootstrap Icons
 */
?>
<!-- Menu Lateral -->
<nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3><i class="bi bi-geo-alt-fill"></i> GeoLoc</h3>
    </div>

    <ul class="list-unstyled components">
        <li class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <a href="dashboard.php">
                <i class="bi bi-map-fill"></i> Mapa Interativo
            </a>
        </li>
        
        <li class="<?= basename($_SERVER['PHP_SELF']) == 'pesquisa.php' ? 'active' : '' ?>">
            <a href="pesquisa.php">
                <i class="bi bi-search"></i> Pesquisa Avançada
            </a>
        </li>
        
        <?php if (ehAdmin()): ?>
        <li class="<?= basename($_SERVER['PHP_SELF']) == 'utilizadores.php' ? 'active' : '' ?>">
            <a href="utilizadores.php">
                <i class="bi bi-people-fill"></i> Gestão de Utilizadores
            </a>
        </li>
        <?php endif; ?>
    </ul>

    <ul class="list-unstyled CTAs">
        <li>
            <a href="perfil.php" class="download">
                <i class="bi bi-person-circle"></i> <?= sanitizar($_SESSION['nome'] ?? 'Perfil') ?>
            </a>
        </li>
        <li>
            <a href="logout.php" class="article">
                <i class="bi bi-box-arrow-right"></i> Sair
            </a>
        </li>
    </ul>
</nav>

<!-- Botão Toggle para mobile -->
<button type="button" id="sidebarCollapse" class="btn btn-info d-md-none">
    <i class="bi bi-list"></i>
</button>