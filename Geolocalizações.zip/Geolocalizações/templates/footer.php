<?php
/**
 * @file footer.php
 * @brief Template de rodapé HTML reutilizável para todas as páginas.
 * 
 * Este ficheiro fecha as tags abertas no header.php, inclui os scripts
 * JavaScript necessários e adiciona o rodapé da página.
 * Deve ser incluído no final de cada página protegida do sistema.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @see header.php
 */

/** @var bool $sem_menu Indica se a página não tem menu lateral */
if (!isset($sem_menu) || !$sem_menu): ?>
        </div><!-- /.container-fluid -->
        
        <!-- Rodapé -->
        <footer class="footer mt-auto py-3 bg-light border-top">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6 text-center text-md-start">
                        <span class="text-muted">
                            &copy; <?= date('Y') ?> Sistema de Geolocalização. Todos os direitos reservados.
                        </span>
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <small class="text-muted">
                            <i class="bi bi-geo-alt-fill text-primary"></i> 
                            v1.0.0 | 
                            <a href="#" class="text-muted text-decoration-none">Ajuda</a> | 
                            <a href="#" class="text-muted text-decoration-none">Termos</a>
                        </small>
                    </div>
                </div>
            </div>
        </footer>
        
    </div><!-- /#content -->
</div><!-- /.wrapper -->
<?php endif; ?>

<!-- Bootstrap Bundle com Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" 
        crossorigin="anonymous"></script>

<!-- Leaflet JS (se necessário) -->
<?php if (isset($incluir_leaflet) && $incluir_leaflet): ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" 
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" 
        crossorigin=""></script>
<script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
<?php endif; ?>

<!-- JavaScript principal da aplicação -->
<script src="js/app.js"></script>

<!-- JavaScript específico da página (opcional) -->
<?php if (isset($js_extra)): ?>
<?= $js_extra ?>
<?php endif; ?>

<!-- Script de inicialização comum -->
<script>
/**
 * @brief Inicializa tooltips e popovers do Bootstrap
 */
document.addEventListener('DOMContentLoaded', function() {
    // Inicializa tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Inicializa popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide para alerts após 5 segundos
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
});
</script>

</body>
</html>