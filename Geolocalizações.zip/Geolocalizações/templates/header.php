<?php
/**
 * @file header.php
 * @brief Template de cabeçalho HTML reutilizável para todas as páginas.
 * 
 * Este ficheiro contém a estrutura inicial do documento HTML, 
 * metadados essenciais e inclusão de folhas de estilo comuns.
 * Deve ser incluído no início de cada página protegida do sistema.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @note Requer que a variável $titulo_pagina seja definida antes da inclusão
 * @see footer.php
 */

/** @var string $titulo_pagina Título específico da página atual */
if (!isset($titulo_pagina)) {
    $titulo_pagina = 'Sistema de Geolocalização';
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <!-- Metadados essenciais -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Geolocalização Interativa">
    <meta name="author" content="Sistema de Geolocalização">
    
    <!-- Título dinâmico da página -->
    <title><?= sanitizar($titulo_pagina) ?> - GeoLoc</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Leaflet CSS (se necessário) -->
    <?php if (isset($incluir_leaflet) && $incluir_leaflet): ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" 
          integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
    <?php endif; ?>
    
    <!-- CSS personalizado da aplicação -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- CSS específico da página (opcional) -->
    <?php if (isset($css_extra)): ?>
    <?= $css_extra ?>
    <?php endif; ?>
</head>
<body<?= isset($body_class) ? ' class="' . sanitizar($body_class) . '"' : '' ?><?= isset($body_data) ? ' ' . $body_data : '' ?>>

<?php
/**
 * @brief Inclui o menu lateral se não for página de login
 */
if (!isset($sem_menu) || !$sem_menu): ?>
<div class="wrapper">
    <?php include __DIR__ . '/menu.php'; ?>
    
    <!-- Conteúdo Principal -->
    <div id="content">
        
        <!-- Barra de Navegação Superior -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
            <div class="container-fluid">
                
                <!-- Botão toggle sidebar (desktop) -->
                <button type="button" id="sidebarCollapseDesktop" class="btn btn-outline-primary d-none d-md-block">
                    <i class="bi bi-list"></i>
                </button>
                
                <!-- Botão toggle sidebar (mobile) -->
                <button type="button" id="sidebarCollapse" class="btn btn-outline-primary d-md-none">
                    <i class="bi bi-list"></i>
                </button>
                
                <!-- Título da página (breadcrumb) -->
                <?php if (isset($breadcrumb)): ?>
                <nav aria-label="breadcrumb" class="ms-3 d-none d-md-block">
                    <ol class="breadcrumb mb-0">
                        <?php foreach ($breadcrumb as $item): ?>
                            <?php if (isset($item['url'])): ?>
                            <li class="breadcrumb-item"><a href="<?= $item['url'] ?>"><?= sanitizar($item['texto']) ?></a></li>
                            <?php else: ?>
                            <li class="breadcrumb-item active" aria-current="page"><?= sanitizar($item['texto']) ?></li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ol>
                </nav>
                <?php endif; ?>
                
                <!-- Menu do Utilizador -->
                <div class="ms-auto d-flex align-items-center">
                    
                    <!-- Notificações (placeholder) -->
                    <div class="dropdown me-3">
                        <button class="btn btn-link text-dark position-relative" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-bell fs-5"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">
                                0
                            </span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><h6 class="dropdown-header">Notificações</h6></li>
                            <li><a class="dropdown-item text-muted" href="#">Sem notificações novas</a></li>
                        </ul>
                    </div>
                    
                    <!-- Perfil do Utilizador -->
                    <div class="">
                        <button class="btn btn-link text-dark text-decoration-none d-flex align-items-center" 
                                type="button" data-bs-toggle="">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" 
                                 style="width: 35px; height: 35px;">
                                <i class="bi bi-person"></i>
                            </div>
                            <span class="d-none d-md-block"><?= sanitizar($_SESSION['nome'] ?? 'Utilizador') ?></span>
                        </button>
                    </div>
                    
                </div>
            </div>
        </nav>
        
        <!-- Container principal do conteúdo -->
        <div class="container-fluid p-4">
            
            <!-- Mensagens de alerta/feedback -->
            <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert alert-<?= $_SESSION['mensagem_tipo'] ?? 'info' ?> alert-dismissible fade show" role="alert">
                <i class="bi bi-<?= $_SESSION['mensagem_tipo'] == 'success' ? 'check-circle' : ($_SESSION['mensagem_tipo'] == 'danger' ? 'exclamation-triangle' : 'info-circle') ?> me-2"></i>
                <?= sanitizar($_SESSION['mensagem']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php 
                unset($_SESSION['mensagem']);
                unset($_SESSION['mensagem_tipo']);
            endif; ?>
            
<?php endif; // fim do if !sem_menu ?>