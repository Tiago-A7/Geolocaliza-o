<?php
/**
 * @file auth.php
 * @brief Funções de autenticação e gestão de sessões.
 * 
 * Este ficheiro contém todas as funções relacionadas com autenticação,
 * verificação de permissões e gestão de utilizadores.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

session_start();

require_once __DIR__ . '/db.php';

/**
 * @brief Verifica se existe um utilizador autenticado na sessão.
 * 
 * @return bool True se o utilizador estiver logado, false caso contrário
 */
function estaLogado() {
    return isset($_SESSION['logado']) && $_SESSION['logado'] === true;
}

/**
 * @brief Verifica se o utilizador autenticado é administrador.
 * 
 * @return bool True se o utilizador for admin, false caso contrário
 */
function ehAdmin() {
    return isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin';
}

/**
 * @brief Obtém o ID do utilizador atualmente autenticado.
 * 
 * @return int|null ID do utilizador ou null se não estiver logado
 */
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * @brief Redireciona para a página de login se não estiver autenticado.
 * 
 * Função de segurança para proteger páginas restritas.
 * 
 * @return void
 */
function requerAutenticacao() {
    if (!estaLogado()) {
        header('Location: index.php');
        exit;
    }
}

/**
 * @brief Valida uma palavra-passe contra o hash armazenado.
 * 
 * Utiliza algoritmo SHA3-256 para comparação segura.
 * 
 * @param string $senha_armazenada Hash da palavra-passe na base de dados
 * @param string $senha_input Palavra-passe introduzida pelo utilizador
 * @return bool True se as palavras-passe coincidirem
 */
function validarSenha($senha_armazenada, $senha_input) {
    if (empty($senha_input)) {
        return false;
    }
    $senha_hash = hash('sha3-256', $senha_input);
    return hash_equals($senha_armazenada, $senha_hash);
}

/**
 * @brief Realiza o logout do utilizador.
 * 
 * Destroi a sessão e redireciona para a página de login.
 * 
 * @return void
 */
function logout() {
    session_destroy();
    header('Location: index.php');
    exit;
}
?>