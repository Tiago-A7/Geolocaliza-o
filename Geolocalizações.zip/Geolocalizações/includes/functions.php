<?php
/**
 * @file functions.php
 * @brief Funções auxiliares do sistema.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

// CORREÇÃO: Verifica se $pdo já foi definido
if (!isset($pdo)) {
    require_once __DIR__ . '/db.php';
}

/**
 * @brief Processa o upload de uma fotografia.
 * 
 * Valida tipo, tamanho (máx 2MB) e move para pasta de uploads.
 * 
 * @param array $ficheiro Array $_FILES do ficheiro enviado
 * @return string|false Nome do ficheiro guardado ou false em caso de erro
 */
function uploadFoto($ficheiro) {
    /** @var int $tamanho_max Tamanho máximo permitido (2MB) */
    $tamanho_max = 2 * 1024 * 1024;
    
    /** @var array $extensoes_permitidas Extensões permitidas */
    $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    // Validações básicas
    if (!isset($ficheiro['error']) || $ficheiro['error'] !== UPLOAD_ERR_OK) {
        error_log("Upload erro: " . ($ficheiro['error'] ?? 'desconhecido'));
        return false;
    }
    
    if ($ficheiro['size'] > $tamanho_max) {
        error_log("Upload erro: Tamanho excede 2MB");
        return false;
    }
    
    // Valida extensão
    $extensao = strtolower(pathinfo($ficheiro['name'], PATHINFO_EXTENSION));
    if (!in_array($extensao, $extensoes_permitidas)) {
        error_log("Upload erro: Extensão não permitida: " . $extensao);
        return false;
    }
    
    // CORREÇÃO: Cria diretório se não existir
    $upload_dir = __DIR__ . '/../uploads/fotos/';
    if (!is_dir($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            error_log("Upload erro: Não foi possível criar diretório: " . $upload_dir);
            return false;
        }
    }
    
    // Gera nome único seguro
    $nome_unico = uniqid('loc_', true) . '.' . $extensao;
    $caminho = $upload_dir . $nome_unico;
    
    // Move ficheiro
    if (move_uploaded_file($ficheiro['tmp_name'], $caminho)) {
        return $nome_unico;
    }
    
    error_log("Upload erro: move_uploaded_file falhou");
    return false;
}

/**
 * @brief Sanitiza uma string para prevenir XSS.
 * 
 * @param string $dados String a ser sanitizada
 * @return string String escapada para uso seguro em HTML
 */
function sanitizar($dados) {
    if ($dados === null) return '';
    return htmlspecialchars($dados, ENT_QUOTES, 'UTF-8');
}

/**
 * @brief Envia informação de um local por email.
 * 
 * @param string $email_destino Email do destinatário
 * @param array $local Dados do local a enviar
 * @return bool True se enviado com sucesso
 */
function enviarEmailLocal($email_destino, $local) {
    $assunto = "Informação sobre: " . $local['nome'];
    
    $mensagem = "
    <html>
    <head><title>{$local['nome']}</title></head>
    <body>
        <h2>{$local['nome']}</h2>
        <p><strong>Categoria:</strong> {$local['categoria']}</p>
        <p><strong>País:</strong> {$local['pais']}</p>
        <p><strong>Cidade:</strong> {$local['cidade']}</p>
        <p><strong>Morada:</strong> {$local['morada']}</p>
        <p><strong>Telefone:</strong> {$local['telefone']}</p>
        <p><strong>Email:</strong> {$local['email']}</p>
        <p><strong>Descrição:</strong> {$local['descricao']}</p>
        <p><strong>Coordenadas:</strong> {$local['latitude']}, {$local['longitude']}</p>
    </body>
    </html>";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: sistema@geolocalizacao.com" . "\r\n";
    
    return mail($email_destino, $assunto, $mensagem, $headers);
}

/**
 * @brief Obtém categorias disponíveis.
 * 
 * @return array Lista de categorias da base de dados
 */
function getCategorias() {
    global $pdo;
    if (!isset($pdo)) return [];
    
    try {
        $stmt = $pdo->query("SELECT * FROM categorias ORDER BY nome");
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * @brief Gera paginação para resultados.
 * 
 * @param int $total Total de registos
 * @param int $pagina Página atual
 * @param int $por_pagina Itens por página
 * @return array Dados de paginação
 */
function paginar($total, $pagina, $por_pagina = 10) {
    $total_paginas = max(1, ceil($total / $por_pagina));
    $pagina = max(1, min($pagina, $total_paginas));
    $inicio = ($pagina - 1) * $por_pagina;
    
    return [
        'inicio' => $inicio,
        'limite' => $por_pagina,
        'total_paginas' => $total_paginas,
        'pagina_atual' => $pagina
    ];
}
?>