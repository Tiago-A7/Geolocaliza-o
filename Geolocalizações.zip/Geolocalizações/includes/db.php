<?php
/**
 * @file db.php
 * @brief Configuração e ligação à base de dados MySQL.
 * 
 * Este ficheiro estabelece a ligação PDO à base de dados do sistema
 * de geolocalização, com suporte a exceções e charset UTF-8.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

/** @var string $host Nome do servidor de base de dados */
$host = 'localhost';

/** @var string $dbname Nome da base de dados */
$dbname = 'geolocalizacao';

/** @var string $username Utilizador da base de dados */
$username = 'root';

/** @var string $password Palavra-passe da base de dados */
$password = '';

try {
    /**
     * @var PDO $pdo Instância da ligação PDO à base de dados
     * 
     * Configuração com:
     * - Charset UTF-8 para suporte a caracteres especiais
     * - Modo de erro em exceções
     * - Modo de fetch associativo por defeito
     */
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    /**
     * @brief Termina a execução em caso de falha na ligação
     */
    die("Erro de ligação à base de dados: " . $e->getMessage());
}
?>