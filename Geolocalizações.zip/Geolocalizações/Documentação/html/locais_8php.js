var locais_8php =
[
    [ "apagarLocal", "locais_8php.html#ab00a3bb8903ae863110fdc084bb3f6a6", null ],
    [ "listarLocais", "locais_8php.html#a873b61f0e927dc2e3c2058dde86d2277", null ],
    [ "obterLocal", "locais_8php.html#a059c6ccb7bc73ea3896803d3b926944b", null ]
];