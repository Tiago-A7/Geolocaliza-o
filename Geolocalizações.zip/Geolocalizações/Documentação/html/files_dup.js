var files_dup =
[
    [ "categorias.php", "categorias_8php.html", "categorias_8php" ],
    [ "dashboard.php", "dashboard_8php.html", null ],
    [ "Index.php", "_index_8php.html", "_index_8php" ],
    [ "locais.php", "locais_8php.html", "locais_8php" ],
    [ "logout.php", "logout_8php.html", "logout_8php" ],
    [ "pesquisa.php", "pesquisa_8php.html", null ],
    [ "utilizadores.php", "utilizadores_8php.html", "utilizadores_8php" ]
];