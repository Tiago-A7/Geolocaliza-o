var logout_8php =
[
    [ "$_SESSION", "logout_8php.html#a5f545b9684799a00f7a14442205b98e3", null ],
    [ "$logout_info", "logout_8php.html#a42a9ae40ab6516de4d058024e3789630", null ],
    [ "$redirect_url", "logout_8php.html#adb1929f736cb07d0c6601e3467eff95b", null ]
];