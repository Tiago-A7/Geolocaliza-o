var indexSectionsWithContent =
{
  0: "$acdeiloptu",
  1: "cdilpu",
  2: "alo",
  3: "$et"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

