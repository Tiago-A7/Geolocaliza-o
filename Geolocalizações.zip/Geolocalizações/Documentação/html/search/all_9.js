var searchData=
[
  ['try_0',['try',['../categorias_8php.html#a04d7f7e25f1ddedc03795aaa8abc1747',1,'try:&#160;categorias.php'],['../utilizadores_8php.html#a9d73cdee83f0f5d7796d65a86a2b97ea',1,'try:&#160;utilizadores.php']]]
];
