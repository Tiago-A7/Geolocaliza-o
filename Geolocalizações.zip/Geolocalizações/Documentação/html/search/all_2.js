var searchData=
[
  ['categorias_2ephp_0',['categorias.php',['../categorias_8php.html',1,'']]]
];
