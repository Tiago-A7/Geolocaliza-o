var searchData=
[
  ['apagarlocal_0',['apagarLocal',['../locais_8php.html#ab00a3bb8903ae863110fdc084bb3f6a6',1,'locais.php']]]
];
