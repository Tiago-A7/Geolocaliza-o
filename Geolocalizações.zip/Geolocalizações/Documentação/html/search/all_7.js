var searchData=
[
  ['obterlocal_0',['obterLocal',['../locais_8php.html#a059c6ccb7bc73ea3896803d3b926944b',1,'locais.php']]]
];
