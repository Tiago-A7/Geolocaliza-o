<?php
/**
 * @file utilizadores.php
 * @brief Página de gestão de utilizadores do sistema.
 * 
 * Permite ao administrador criar, editar, ativar/desativar e
 * redefinir palavras-passe dos utilizadores. Inclui validações
 * de segurança e diferentes níveis de permissão.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @note Apenas administradores têm acesso a esta página
 */

require_once __DIR__ . '/includes/auth.php';
requerAutenticacao();

// Verifica permissão de admin
if (!ehAdmin()) {
    $_SESSION['mensagem'] = 'Acesso restrito a administradores.';
    $_SESSION['mensagem_tipo'] = 'danger';
    header('Location: dashboard.php');
    exit;
}

require_once __DIR__ . '/includes/functions.php';

/** @var string $modo Modo atual: listar, criar, editar, ver */
$modo = $_GET['modo'] ?? 'listar';

/** @var int|null $edit_id ID do utilizador em edição */
$edit_id = isset($_GET['id']) ? (int)$_GET['id'] : null;

/** @var array $erros Erros de validação */
$erros = [];

/** @var array $dados Dados do formulário */
$dados = [
    'nome' => '',
    'email' => '',
    'tipo' => 'utilizador',
    'ativo' => 1
];

/**
 * @brief Processa formulário de criação/edição
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    
    // Validação comum
    $dados['nome'] = trim($_POST['nome'] ?? '');
    $dados['email'] = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $dados['tipo'] = in_array($_POST['tipo'] ?? '', ['admin', 'utilizador']) ? $_POST['tipo'] : 'utilizador';
    $dados['ativo'] = isset($_POST['ativo']) ? 1 : 0;
    
    if (empty($dados['nome'])) {
        $erros[] = 'O nome é obrigatório.';
    }
    
    if (!$dados['email']) {
        $erros[] = 'Email inválido.';
    }
    
    // Validação de palavra-passe (obrigatória apenas na criação)
    $senha = $_POST['senha'] ?? '';
    $senha_confirmar = $_POST['senha_confirmar'] ?? '';
    
    if ($acao === 'criar' && empty($senha)) {
        $erros[] = 'A palavra-passe é obrigatória para novos utilizadores.';
    }
    
    if (!empty($senha) && strlen($senha) < 6) {
        $erros[] = 'A palavra-passe deve ter pelo menos 6 caracteres.';
    }
    
    if (!empty($senha) && $senha !== $senha_confirmar) {
        $erros[] = 'As palavras-passe não coincidem.';
    }
    
    if (empty($erros)) {
        try {
            if ($acao === 'criar') {
                // Verifica email duplicado
                $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE email = ?");
                $stmt->execute([$dados['email']]);
                if ($stmt->fetch()) {
                    $erros[] = 'Já existe um utilizador com este email.';
                } else {
                    // Cria novo utilizador
                    $senha_hash = hash('sha3-256', $senha);
                    $stmt = $pdo->prepare("
                        INSERT INTO utilizadores (nome, email, senha, tipo, ativo, criado_em) 
                        VALUES (:nome, :email, :senha, :tipo, :ativo, NOW())
                    ");
                    $stmt->execute([
                        ':nome' => $dados['nome'],
                        ':email' => $dados['email'],
                        ':senha' => $senha_hash,
                        ':tipo' => $dados['tipo'],
                        ':ativo' => $dados['ativo']
                    ]);
                    
                    $_SESSION['mensagem'] = 'Utilizador criado com sucesso!';
                    $_SESSION['mensagem_tipo'] = 'success';
                    header('Location: utilizadores.php');
                    exit;
                }
                
            } elseif ($acao === 'editar' && $edit_id) {
                // Verifica se não está a editar a si mesmo para tipo
                if ($edit_id == getUserId() && $dados['tipo'] !== 'admin') {
                    $erros[] = 'Não pode remover seus próprios privilégios de administrador.';
                } else {
                    // Verifica email duplicado (exceto o próprio)
                    $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE email = ? AND id != ?");
                    $stmt->execute([$dados['email'], $edit_id]);
                    if ($stmt->fetch()) {
                        $erros[] = 'Já existe outro utilizador com este email.';
                    } else {
                        // Atualiza utilizador
                        $sql = "UPDATE utilizadores SET nome = :nome, email = :email, tipo = :tipo, ativo = :ativo";
                        $params = [
                            ':nome' => $dados['nome'],
                            ':email' => $dados['email'],
                            ':tipo' => $dados['tipo'],
                            ':ativo' => $dados['ativo'],
                            ':id' => $edit_id
                        ];
                        
                        // Atualiza senha se fornecida
                        if (!empty($senha)) {
                            $sql .= ", senha = :senha";
                            $params[':senha'] = hash('sha3-256', $senha);
                        }
                        
                        $sql .= " WHERE id = :id";
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute($params);
                        
                        $_SESSION['mensagem'] = 'Utilizador atualizado com sucesso!';
                        $_SESSION['mensagem_tipo'] = 'success';
                        header('Location: utilizadores.php');
                        exit;
                    }
                }
            }
        } catch (PDOException $e) {
            $erros[] = 'Erro na base de dados: ' . $e->getMessage();
        }
    }
}

/**
 * @brief Processa ações especiais (ativar/desativar/redefinir senha)
 */
if ($modo === 'toggle' && $edit_id) {
    try {
        // Impede desativar a si mesmo
        if ($edit_id == getUserId()) {
            $_SESSION['mensagem'] = 'Não pode desativar sua própria conta.';
            $_SESSION['mensagem_tipo'] = 'danger';
        } else {
            $stmt = $pdo->prepare("UPDATE utilizadores SET ativo = NOT ativo WHERE id = ?");
            $stmt->execute([$edit_id]);
            
            $_SESSION['mensagem'] = 'Estado do utilizador alterado com sucesso!';
            $_SESSION['mensagem_tipo'] = 'success';
        }
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = 'Erro ao alterar estado do utilizador.';
        $_SESSION['mensagem_tipo'] = 'danger';
    }
    header('Location: utilizadores.php');
    exit;
}

/**
 * @brief Carrega dados para edição
 */
if ($modo === 'editar' && $edit_id) {
    try {
        $stmt = $pdo->prepare("SELECT id, nome, email, tipo, ativo FROM utilizadores WHERE id = ?");
        $stmt->execute([$edit_id]);
        $utilizador = $stmt->fetch();
        
        if ($utilizador) {
            $dados = $utilizador;
        } else {
            $_SESSION['mensagem'] = 'Utilizador não encontrado.';
            $_SESSION['mensagem_tipo'] = 'danger';
            header('Location: utilizadores.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = 'Erro ao carregar utilizador.';
        $_SESSION['mensagem_tipo'] = 'danger';
        header('Location: utilizadores.php');
        exit;
    }
}

/**
 * @brief Busca estatísticas e lista de utilizadores
 */
try {
    // Estatísticas
    $stats = [
        'total' => $pdo->query("SELECT COUNT(*) FROM utilizadores")->fetchColumn(),
        'ativos' => $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE ativo = 1")->fetchColumn(),
        'admins' => $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE tipo = 'admin'")->fetchColumn(),
        'locais_total' => $pdo->query("SELECT COUNT(*) FROM locais WHERE ativo = 1")->fetchColumn()
    ];
    
    // Lista de utilizadores com contagem de locais
    $stmt = $pdo->query("
        SELECT 
            u.*,
            COUNT(DISTINCT l.id) as total_locais
        FROM utilizadores u
        LEFT JOIN locais l ON u.id = l.criado_por AND l.ativo = 1
        GROUP BY u.id
        ORDER BY u.criado_em DESC
    ");
    $utilizadores = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $utilizadores = [];
    $erros[] = 'Erro ao carregar lista de utilizadores.';
}

// Configuração do template
$titulo_pagina = 'Gestão de Utilizadores';
$breadcrumb = [
    ['url' => 'dashboard.php', 'texto' => 'Dashboard'],
    ['texto' => 'Utilizadores']
];

include __DIR__ . '/templates/header.php';
?>

<!-- Cabeçalho -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-0"><i class="bi bi-people-fill text-primary"></i> Gestão de Utilizadores</h2>
        <p class="text-muted mb-0">Administre as contas de acesso ao sistema</p>
    </div>
    
    <?php if ($modo === 'listar'): ?>
    <a href="utilizadores.php?modo=criar" class="btn btn-primary">
        <i class="bi bi-person-plus-fill"></i> Novo Utilizador
    </a>
    <?php else: ?>
    <a href="utilizadores.php" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Voltar à Lista
    </a>
    <?php endif; ?>
</div>

<?php if (!empty($erros)): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <h6><i class="bi bi-exclamation-triangle-fill"></i> Erros encontrados:</h6>
    <ul class="mb-0">
        <?php foreach ($erros as $erro): ?>
        <li><?= sanitizar($erro) ?></li>
        <?php endforeach; ?>
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($modo === 'listar'): ?>
<!-- Estatísticas -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase">Total Utilizadores</h6>
                        <h2 class="mb-0"><?= $stats['total'] ?></h2>
                    </div>
                    <i class="bi bi-people fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase">Ativos</h6>
                        <h2 class="mb-0"><?= $stats['ativos'] ?></h2>
                    </div>
                    <i class="bi bi-person-check fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase">Administradores</h6>
                        <h2 class="mb-0"><?= $stats['admins'] ?></h2>
                    </div>
                    <i class="bi bi-shield-lock fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="text-uppercase">Total Locais</h6>
                        <h2 class="mb-0"><?= $stats['locais_total'] ?></h2>
                    </div>
                    <i class="bi bi-geo-alt fs-1 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Lista de Utilizadores -->
<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Estado</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Tipo</th>
                        <th>Locais Criados</th>
                        <th>Registo</th>
                        <th class="text-end">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($utilizadores as $user): ?>
                    <tr class="<?= $user['ativo'] ? '' : 'table-secondary' ?>">
                        <td>
                            <?php if ($user['ativo']): ?>
                            <span class="badge bg-success"><i class="bi bi-check-circle"></i> Ativo</span>
                            <?php else: ?>
                            <span class="badge bg-secondary"><i class="bi bi-x-circle"></i> Inativo</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="bg-<?= $user['tipo'] === 'admin' ? 'danger' : 'primary' ?> text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 35px; height: 35px;">
                                    <i class="bi bi-person"></i>
                                </div>
                                <div>
                                    <strong><?= sanitizar($user['nome']) ?></strong>
                                    <?php if ($user['id'] == getUserId()): ?>
                                    <span class="badge bg-warning text-dark ms-1">Você</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td><?= sanitizar($user['email']) ?></td>
                        <td>
                            <?php if ($user['tipo'] === 'admin'): ?>
                            <span class="badge bg-danger"><i class="bi bi-shield-fill"></i> Admin</span>
                            <?php else: ?>
                            <span class="badge bg-primary"><i class="bi bi-person"></i> Utilizador</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-info"><?= $user['total_locais'] ?> locais</span>
                        </td>
                        <td>
                            <small class="text-muted">
                                <?= date('d/m/Y', strtotime($user['criado_em'])) ?>
                            </small>
                        </td>
                        <td class="text-end">
                            <a href="utilizadores.php?modo=editar&id=<?= $user['id'] ?>" 
                               class="btn btn-sm btn-outline-warning" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </a>
                            
                            <a href="utilizadores.php?modo=toggle&id=<?= $user['id'] ?>" 
                               class="btn btn-sm btn-outline-<?= $user['ativo'] ? 'secondary' : 'success' ?>" 
                               title="<?= $user['ativo'] ? 'Desativar' : 'Ativar' ?>"
                               onclick="return confirm('Tem certeza que deseja <?= $user['ativo'] ? 'desativar' : 'ativar' ?> este utilizador?')">
                                <i class="bi bi-<?= $user['ativo'] ? 'pause' : 'play' ?>-fill"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($utilizadores)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                            Nenhum utilizador encontrado.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php else: ?>
<!-- Formulário Criar/Editar -->
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm">
            <div class="card-header bg-<?= $modo === 'criar' ? 'primary' : 'warning' ?> text-white">
                <h5 class="mb-0">
                    <i class="bi bi-<?= $modo === 'criar' ? 'person-plus' : 'pencil' ?>"></i>
                    <?= $modo === 'criar' ? 'Novo Utilizador' : 'Editar Utilizador' ?>
                </h5>
            </div>
            <div class="card-body">
                <form method="POST" action="utilizadores.php<?= $modo === 'editar' ? '?modo=editar&id=' . $edit_id : '' ?>">
                    <input type="hidden" name="acao" value="<?= $modo ?>">
                    
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome Completo *</label>
                        <input type="text" class="form-control" id="nome" name="nome" 
                               value="<?= sanitizar($dados['nome']) ?>" required maxlength="100">
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= sanitizar($dados['email']) ?>" required maxlength="100">
                    </div>
                    
                    <div class="mb-3">
                        <label for="tipo" class="form-label">Tipo de Conta *</label>
                        <select class="form-select" id="tipo" name="tipo" required>
                            <option value="utilizador" <?= $dados['tipo'] === 'utilizador' ? 'selected' : '' ?>>
                                Utilizador Normal (pode gerir apenas os seus locais)
                            </option>
                            <option value="admin" <?= $dados['tipo'] === 'admin' ? 'selected' : '' ?>>
                                Administrador (acesso total ao sistema)
                            </option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="senha" class="form-label">
                            Palavra-passe <?= $modo === 'criar' ? '*' : '(deixe em branco para manter a atual)' ?>
                        </label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="senha" name="senha" 
                                   <?= $modo === 'criar' ? 'required' : '' ?> minlength="6">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('senha')">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">Mínimo 6 caracteres.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="senha_confirmar" class="form-label">Confirmar Palavra-passe</label>
                        <input type="password" class="form-control" id="senha_confirmar" name="senha_confirmar">
                    </div>
                    
                    <?php if ($modo === 'editar'): ?>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="ativo" name="ativo" 
                               <?= $dados['ativo'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="ativo">Conta Ativa</label>
                    </div>
                    <?php endif; ?>
                    
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-<?= $modo === 'criar' ? 'primary' : 'warning' ?>">
                            <i class="bi bi-check-lg"></i> 
                            <?= $modo === 'criar' ? 'Criar Utilizador' : 'Guardar Alterações' ?>
                        </button>
                        <a href="utilizadores.php" class="btn btn-outline-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
/**
 * @brief Alterna visibilidade da palavra-passe
 */
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    field.type = field.type === 'password' ? 'text' : 'password';
}
</script>

<?php endif; ?>

<?php include __DIR__ . '/templates/footer.php'; ?>