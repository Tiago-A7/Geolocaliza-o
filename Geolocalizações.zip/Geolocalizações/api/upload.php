<?php
/**
 * @file upload.php
 * @brief API para upload e gestão de ficheiros (fotografias).
 * 
 * Fornece endpoints para upload, redimensionamento e eliminação
 * de imagens associadas a locais. Inclui validações de segurança
 * e otimização de imagens.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @note Diretório de upload: /uploads/fotos/
 * @note Tamanho máximo: 2MB
 * @note Dimensões máximas: 1920x1080 (redimensiona automaticamente)
 */

require_once __DIR__ . '/../includes/auth.php';
requerAutenticacao();
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

/** @var string $acao Ação solicitada via parâmetro 'acao' */
$acao = $_GET['acao'] ?? $_POST['acao'] ?? '';

/** @var string $UPLOAD_DIR Diretório base para uploads */
define('UPLOAD_DIR', __DIR__ . '/../uploads/fotos/');

/** @var int $MAX_FILE_SIZE Tamanho máximo em bytes (2MB) */
define('MAX_FILE_SIZE', 2 * 1024 * 1024);

/** @var int $MAX_WIDTH Largura máxima da imagem */
define('MAX_WIDTH', 1920);

/** @var int $MAX_HEIGHT Altura máxima da imagem */
define('MAX_HEIGHT', 1080);

// Cria diretório se não existir
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

switch ($acao) {
    case 'upload':
        processarUpload();
        break;
        
    case 'delete':
        apagarFicheiro();
        break;
        
    case 'temp':
        uploadTemporario();
        break;
        
    default:
        http_response_code(400);
        echo json_encode([
            'status' => 'erro',
            'mensagem' => 'Ação não especificada. Use: upload, delete ou temp'
        ]);
}

/**
 * @brief Processa upload de imagem com validações e otimização.
 * 
 * Valida tipo MIME, tamanho, dimensões e redimensiona se necessário.
 * Gera nome único e guarda metadados.
 * 
 * @return void
 */
function processarUpload() {
    // Verifica se ficheiro foi enviado
    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Nenhum ficheiro enviado']);
        return;
    }
    
    $ficheiro = $_FILES['foto'];
    
    // Verifica erros de upload
    if ($ficheiro['error'] !== UPLOAD_ERR_OK) {
        $mensagens_erro = [
            UPLOAD_ERR_INI_SIZE => 'Ficheiro excede o limite do servidor',
            UPLOAD_ERR_FORM_SIZE => 'Ficheiro excede o limite do formulário',
            UPLOAD_ERR_PARTIAL => 'Upload interrompido',
            UPLOAD_ERR_NO_TMP_DIR => 'Pasta temporária não encontrada',
            UPLOAD_ERR_CANT_WRITE => 'Erro ao gravar ficheiro',
            UPLOAD_ERR_EXTENSION => 'Extensão bloqueada pelo servidor'
        ];
        
        echo json_encode([
            'status' => 'erro',
            'mensagem' => $mensagens_erro[$ficheiro['error']] ?? 'Erro desconhecido no upload'
        ]);
        return;
    }
    
    // Valida tamanho
    if ($ficheiro['size'] > MAX_FILE_SIZE) {
        echo json_encode([
            'status' => 'erro',
            'mensagem' => 'Ficheiro muito grande. Máximo: 2MB'
        ]);
        return;
    }
    
    // Valida tipo MIME real (não confia apenas na extensão)
    $tipos_permitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime_real = $finfo->file($ficheiro['tmp_name']);
    
    if (!in_array($mime_real, $tipos_permitidos)) {
        echo json_encode([
            'status' => 'erro',
            'mensagem' => 'Tipo de ficheiro não permitido. Use: JPG, PNG, GIF ou WebP'
        ]);
        return;
    }
    
    // Gera nome único seguro
    $extensao = pathinfo($ficheiro['name'], PATHINFO_EXTENSION);
    $nome_base = uniqid('loc_', true);
    $nome_ficheiro = $nome_base . '.' . strtolower($extensao);
    $caminho_destino = UPLOAD_DIR . $nome_ficheiro;
    
    // Processa imagem (redimensiona se necessário)
    try {
        $imagem_processada = processarImagem($ficheiro['tmp_name'], $mime_real);
        
        if ($imagem_processada) {
            // Guarda imagem processada
            switch ($mime_real) {
                case 'image/jpeg':
                    imagejpeg($imagem_processada, $caminho_destino, 85);
                    break;
                case 'image/png':
                    imagepng($imagem_processada, $caminho_destino, 6);
                    break;
                case 'image/gif':
                    imagegif($imagem_processada, $caminho_destino);
                    break;
                case 'image/webp':
                    imagewebp($imagem_processada, $caminho_destino, 85);
                    break;
            }
            imagedestroy($imagem_processada);
        } else {
            // Move sem processar se falhar o redimensionamento
            move_uploaded_file($ficheiro['tmp_name'], $caminho_destino);
        }
        
        // Guarda metadados em JSON (opcional)
        $metadados = [
            'original' => $ficheiro['name'],
            'uploaded_by' => getUserId(),
            'uploaded_at' => date('Y-m-d H:i:s'),
            'mime_type' => $mime_real,
            'size' => filesize($caminho_destino)
        ];
        file_put_contents(UPLOAD_DIR . $nome_base . '.json', json_encode($metadados));
        
        echo json_encode([
            'status' => 'ok',
            'mensagem' => 'Upload realizado com sucesso',
            'ficheiro' => $nome_ficheiro,
            'url' => 'uploads/fotos/' . $nome_ficheiro,
            'tamanho' => formatarTamanho(filesize($caminho_destino))
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'erro',
            'mensagem' => 'Erro ao processar imagem: ' . $e->getMessage()
        ]);
    }
}

/**
 * @brief Redimensiona e otimiza imagem mantendo proporção.
 * 
 * @param string $caminho_origem Caminho da imagem original
 * @param string $mime_type Tipo MIME da imagem
 * @return resource|false Recurso GD da imagem processada ou false
 */
function processarImagem($caminho_origem, $mime_type) {
    // Cria imagem a partir do ficheiro
    switch ($mime_type) {
        case 'image/jpeg':
            $origem = imagecreatefromjpeg($caminho_origem);
            break;
        case 'image/png':
            $origem = imagecreatefrompng($caminho_origem);
            break;
        case 'image/gif':
            $origem = imagecreatefromgif($caminho_origem);
            break;
        case 'image/webp':
            $origem = imagecreatefromwebp($caminho_origem);
            break;
        default:
            return false;
    }
    
    if (!$origem) {
        return false;
    }
    
    // Obtém dimensões originais
    $largura_origem = imagesx($origem);
    $altura_origem = imagesy($origem);
    
    // Calcula novas dimensões mantendo proporção
    $ratio = min(MAX_WIDTH / $largura_origem, MAX_HEIGHT / $altura_origem, 1);
    
    if ($ratio === 1) {
        // Não precisa redimensionar
        return $origem;
    }
    
    $nova_largura = (int)($largura_origem * $ratio);
    $nova_altura = (int)($altura_origem * $ratio);
    
    // Cria nova imagem redimensionada
    $destino = imagecreatetruecolor($nova_largura, $nova_altura);
    
    // Preserva transparência para PNG
    if ($mime_type === 'image/png') {
        imagealphablending($destino, false);
        imagesavealpha($destino, true);
    }
    
    // Redimensiona com qualidade
    imagecopyresampled(
        $destino, $origem,
        0, 0, 0, 0,
        $nova_largura, $nova_altura,
        $largura_origem, $altura_origem
    );
    
    imagedestroy($origem);
    
    return $destino;
}

/**
 * @brief Apaga ficheiro de imagem e metadados associados.
 * 
 * @return void
 */
function apagarFicheiro() {
    /** @var string $ficheiro Nome do ficheiro a apagar */
    $ficheiro = basename($_POST['ficheiro'] ?? '');
    
    if (empty($ficheiro)) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Ficheiro não especificado']);
        return;
    }
    
    $caminho = UPLOAD_DIR . $ficheiro;
    $caminho_json = UPLOAD_DIR . pathinfo($ficheiro, PATHINFO_FILENAME) . '.json';
    
    // Verifica se ficheiro existe e está dentro do diretório permitido
    if (!file_exists($caminho) || strpos(realpath($caminho), realpath(UPLOAD_DIR)) !== 0) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Ficheiro não encontrado']);
        return;
    }
    
    // Verifica permissão (apenas admin ou quem fez upload)
    $permitido = ehAdmin();
    if (!$permitido && file_exists($caminho_json)) {
        $metadados = json_decode(file_get_contents($caminho_json), true);
        $permitido = ($metadados['uploaded_by'] ?? null) == getUserId();
    }
    
    if (!$permitido) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Sem permissão para apagar']);
        return;
    }
    
    // Apaga ficheiros
    $sucesso = unlink($caminho);
    if (file_exists($caminho_json)) {
        unlink($caminho_json);
    }
    
    if ($sucesso) {
        echo json_encode(['status' => 'ok', 'mensagem' => 'Ficheiro apagado com sucesso']);
    } else {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Erro ao apagar ficheiro']);
    }
}

/**
 * @brief Upload temporário para preview antes de guardar.
 * 
 * Guarda em pasta temporária e retorna dados para preview.
 * 
 * @return void
 */
function uploadTemporario() {
    if (!isset($_FILES['foto'])) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Nenhum ficheiro enviado']);
        return;
    }
    
    $ficheiro = $_FILES['foto'];
    
    if ($ficheiro['size'] > MAX_FILE_SIZE) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Ficheiro muito grande']);
        return;
    }
    
    $temp_dir = sys_get_temp_dir() . '/geoloc_' . getUserId() . '/';
    if (!is_dir($temp_dir)) {
        mkdir($temp_dir, 0755, true);
    }
    
    $nome_temp = uniqid('temp_') . '.jpg';
    $caminho_temp = $temp_dir . $nome_temp;
    
    // Processa e guarda temporariamente
    $processada = processarImagem($ficheiro['tmp_name'], $ficheiro['type']);
    if ($processada) {
        imagejpeg($processada, $caminho_temp, 80);
        imagedestroy($processada);
        
        // Converte para base64 para preview
        $base64 = base64_encode(file_get_contents($caminho_temp));
        
        echo json_encode([
            'status' => 'ok',
            'temp_file' => $nome_temp,
            'preview' => 'data:image/jpeg;base64,' . $base64,
            'tamanho' => formatarTamanho(filesize($caminho_temp))
        ]);
    } else {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Erro ao processar imagem']);
    }
}

/**
 * @brief Formata tamanho em bytes para formato legível.
 * 
 * @param int $bytes Tamanho em bytes
 * @return string Tamanho formatado (ex: 1.5 MB)
 */
function formatarTamanho($bytes) {
    $unidades = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($unidades) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $unidades[$i];
}
?>