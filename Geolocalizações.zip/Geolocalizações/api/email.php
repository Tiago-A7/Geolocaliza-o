<?php
/**
 * @file email.php
 * @brief API para envio de informação de locais por email.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

require_once __DIR__ . '/../includes/auth.php';
requerAutenticacao();
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'erro', 'mensagem' => 'Método não permitido']);
    exit;
}

/** @var int $local_id ID do local a enviar */
$local_id = (int)($_POST['local_id'] ?? 0);

/** @var string $email_destino Email do destinatário */
$email_destino = filter_var($_POST['email_destino'] ?? '', FILTER_VALIDATE_EMAIL);

/** @var string $mensagem_adicional Mensagem personalizada */
$mensagem_adicional = trim($_POST['mensagem'] ?? '');

if (!$local_id || !$email_destino) {
    echo json_encode(['status' => 'erro', 'mensagem' => 'Dados inválidos']);
    exit;
}

try {
    // Busca dados do local
    $stmt = $pdo->prepare("
        SELECT l.*, c.nome as categoria
        FROM locais l
        JOIN categorias c ON l.categoria_id = c.id
        WHERE l.id = ? AND l.ativo = 1
    ");
    $stmt->execute([$local_id]);
    $local = $stmt->fetch();
    
    if (!$local) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Local não encontrado']);
        exit;
    }
    
    // Prepara email
    $assunto = "Informação sobre: " . $local['nome'];
    
    $mensagem = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #4e73df; color: white; padding: 20px; text-align: center; }
            .content { background: #f8f9fc; padding: 20px; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #4e73df; }
            .map-link { display: inline-block; margin-top: 20px; padding: 10px 20px; 
                       background: #4e73df; color: white; text-decoration: none; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>{$local['nome']}</h2>
                <p>{$local['categoria']}</p>
            </div>
            <div class='content'>
    ";
    
    if ($mensagem_adicional) {
        $mensagem .= "<p><em>" . nl2br(htmlspecialchars($mensagem_adicional)) . "</em></p><hr>";
    }
    
    $mensagem .= "
                <div class='field'>
                    <span class='label'>Localização:</span> {$local['cidade']}, {$local['pais']}
                </div>
                <div class='field'>
                    <span class='label'>Morada:</span> " . ($local['morada'] ?: 'N/A') . "
                </div>
                <div class='field'>
                    <span class='label'>Telefone:</span> " . ($local['telefone'] ?: 'N/A') . "
                </div>
                <div class='field'>
                    <span class='label'>Email:</span> " . ($local['email'] ?: 'N/A') . "
                </div>
                <div class='field'>
                    <span class='label'>Descrição:</span> " . nl2br(htmlspecialchars($local['descricao'] ?: 'N/A')) . "
                </div>
                
                <center>
                    <a href='https://www.google.com/maps?q={$local['latitude']},{$local['longitude']}' 
                       class='map-link' target='_blank'>
                        Ver no Google Maps
                    </a>
                </center>
            </div>
            <p style='text-align: center; color: #666; font-size: 12px; margin-top: 20px;'>
                Enviado por " . $_SESSION['nome'] . " via Sistema de Geolocalização
            </p>
        </div>
    </body>
    </html>";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . $_SESSION['email'] . "\r\n";
    
    if (mail($email_destino, $assunto, $mensagem, $headers)) {
        echo json_encode(['status' => 'ok', 'mensagem' => 'Email enviado com sucesso']);
    } else {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Falha ao enviar email']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['status' => 'erro', 'mensagem' => 'Erro no sistema']);
}
?>