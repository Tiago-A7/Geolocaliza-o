<?php
/**
 * @file locais.php
 * @brief API REST para gestão de locais georreferenciados.
 * 
 * Endpoints:
 * - GET: Lista locais ou obtém detalhes de um específico
 * - POST: Cria ou atualiza local (com suporte a upload de fotos)
 * - DELETE: Remove local (apenas admin ou criador)
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

// CORREÇÃO: Caminho correto para includes
require_once __DIR__ . '/includes/auth.php';
requerAutenticacao();
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

// CORREÇÃO: Verifica se $pdo existe (vindo de db.php)
if (!isset($pdo)) {
    http_response_code(500);
    echo json_encode(['status' => 'erro', 'mensagem' => 'Erro de configuração da base de dados']);
    exit;
}

/** @var string $metodo Método HTTP da requisição */
$metodo = $_SERVER['REQUEST_METHOD'];

// CORREÇÃO: Log de debug (remover em produção)
error_log("API Locais - Método: $metodo, GET: " . print_r($_GET, true));

switch ($metodo) {
    case 'GET':
        if (isset($_GET['id'])) {
            obterLocal((int)$_GET['id']);
        } else {
            listarLocais();
        }
        break;
        
    case 'POST':
        guardarLocal();
        break;
        
    case 'DELETE':
        if (isset($_GET['id'])) {
            apagarLocal((int)$_GET['id']);
        } else {
            http_response_code(400);
            echo json_encode(['status' => 'erro', 'mensagem' => 'ID não fornecido']);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['status' => 'erro', 'mensagem' => 'Método não permitido: ' . $metodo]);
}

/**
 * @brief Lista todos os locais com informações relacionadas.
 * @return void
 */
function listarLocais() {
    global $pdo;
    
    try {
        $sql = "
            SELECT 
                l.id,
                l.nome,
                l.latitude,
                l.longitude,
                l.pais,
                l.cidade,
                l.morada,
                l.telefone,
                l.email,
                l.descricao,
                l.foto,
                l.criado_por,
                c.id as categoria_id,
                c.nome as categoria,
                c.cor,
                c.letras,
                u.nome as autor
            FROM locais l
            JOIN categorias c ON l.categoria_id = c.id
            JOIN utilizadores u ON l.criado_por = u.id
            WHERE l.ativo = 1
            ORDER BY l.id DESC
        ";
        
        $stmt = $pdo->query($sql);
        $locais = $stmt->fetchAll();
        
        // CORREÇÃO: Garante que sempre retorna array válido
        if (!$locais) {
            $locais = [];
        }
        
        echo json_encode($locais, JSON_UNESCAPED_UNICODE);
        
    } catch (PDOException $e) {
        error_log("Erro listarLocais: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['status' => 'erro', 'mensagem' => 'Erro ao listar locais: ' . $e->getMessage()]);
    }
}

/**
 * @brief Obtém detalhes de um local específico.
 * @param int $id ID do local
 * @return void
 */
function obterLocal($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT l.*, c.nome as categoria, c.cor, c.letras
            FROM locais l
            JOIN categorias c ON l.categoria_id = c.id
            WHERE l.id = ? AND l.ativo = 1
        ");
        $stmt->execute([$id]);
        $local = $stmt->fetch();
        
        if (!$local) {
            http_response_code(404);
            echo json_encode(['status' => 'erro', 'mensagem' => 'Local não encontrado']);
            return;
        }
        
        // Verifica permissão
        if (!ehAdmin() && $local['criado_por'] != getUserId()) {
            http_response_code(403);
            echo json_encode(['status' => 'erro', 'mensagem' => 'Sem permissão']);
            return;
        }
        
        echo json_encode($local, JSON_UNESCAPED_UNICODE);
        
    } catch (PDOException $e) {
        error_log("Erro obterLocal: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['status' => 'erro', 'mensagem' => 'Erro ao obter local']);
    }
}

/**
 * @brief Cria ou atualiza um local.
 * @return void
 */
function guardarLocal() {
    global $pdo;
    
    // CORREÇÃO: Verifica se é POST com dados
    if (empty($_POST) && empty($_FILES)) {
        echo json_encode(['status' => 'erro', 'mensagem' => 'Nenhum dado recebido']);
        return;
    }
    
    /** @var int|null $id ID do local (null para novo) */
    $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
    
    /** @var array $dados Dados validados do formulário */
    $dados = [
        'nome' => trim($_POST['nome'] ?? ''),
        'categoria_id' => (int)($_POST['categoria_id'] ?? 0),
        'pais' => trim($_POST['pais'] ?? ''),
        'cidade' => trim($_POST['cidade'] ?? ''),
        'morada' => trim($_POST['morada'] ?? ''),
        'telefone' => trim($_POST['telefone'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'descricao' => trim($_POST['descricao'] ?? ''),
        'latitude' => (float)($_POST['latitude'] ?? 0),
        'longitude' => (float)($_POST['longitude'] ?? 0)
    ];
    
    // CORREÇÃO: Validação mais robusta
    $campos_obrigatorios = ['nome', 'pais', 'cidade'];
    $erros_validacao = [];
    
    foreach ($campos_obrigatorios as $campo) {
        if (empty($dados[$campo])) {
            $erros_validacao[] = "O campo {$campo} é obrigatório.";
        }
    }
    
    if ($dados['categoria_id'] <= 0) {
        $erros_validacao[] = "Selecione uma categoria válida.";
    }
    
    if ($dados['latitude'] == 0 || $dados['longitude'] == 0) {
        $erros_validacao[] = "Coordenadas inválidas. Clique no mapa para definir a localização.";
    }
    
    if (!empty($erros_validacao)) {
        echo json_encode(['status' => 'erro', 'mensagem' => implode(' ', $erros_validacao)]);
        return;
    }
    
    try {
        // Processa upload de foto se existir
        $foto_nome = null;
        if (!empty($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $foto_nome = uploadFoto($_FILES['foto']);
            if (!$foto_nome) {
                echo json_encode(['status' => 'erro', 'mensagem' => 'Erro no upload da foto. Verifique o tamanho (máx 2MB) e formato (JPG, PNG, GIF).']);
                return;
            }
        }
        
        if ($id) {
            // ATUALIZAÇÃO
            $stmt = $pdo->prepare("SELECT criado_por, foto FROM locais WHERE id = ?");
            $stmt->execute([$id]);
            $existente = $stmt->fetch();
            
            if (!$existente) {
                echo json_encode(['status' => 'erro', 'mensagem' => 'Local não encontrado']);
                return;
            }
            
            // Verifica permissão
            if (!ehAdmin() && $existente['criado_por'] != getUserId()) {
                echo json_encode(['status' => 'erro', 'mensagem' => 'Sem permissão para editar este local']);
                return;
            }
            
            // Monta SQL de atualização dinamicamente
            $campos_sql = [];
            $valores = [];
            
            foreach ($dados as $campo => $valor) {
                $campos_sql[] = "$campo = :$campo";
                $valores[":$campo"] = $valor;
            }
            
            // Adiciona foto se foi enviada nova
            if ($foto_nome) {
                $campos_sql[] = "foto = :foto";
                $valores[':foto'] = $foto_nome;
                
                // Apaga foto antiga
                if ($existente['foto'] && file_exists(__DIR__ . '/../uploads/fotos/' . $existente['foto'])) {
                    unlink(__DIR__ . '/../uploads/fotos/' . $existente['foto']);
                }
            }
            
            $valores[':id'] = $id;
            $sql = "UPDATE locais SET " . implode(', ', $campos_sql) . " WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($valores);
            
            echo json_encode(['status' => 'ok', 'mensagem' => 'Local atualizado com sucesso', 'id' => $id]);
            
        } else {
            // INSERÇÃO
            $dados['criado_por'] = getUserId();
            $dados['foto'] = $foto_nome;
            $dados['ativo'] = 1;
            
            $campos = implode(', ', array_keys($dados));
            $placeholders = ':' . implode(', :', array_keys($dados));
            
            $sql = "INSERT INTO locais ($campos, criado_em) VALUES ($placeholders, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($dados);
            
            $novo_id = $pdo->lastInsertId();
            
            echo json_encode(['status' => 'ok', 'mensagem' => 'Local criado com sucesso', 'id' => $novo_id]);
        }
        
    } catch (PDOException $e) {
        error_log("Erro guardarLocal: " . $e->getMessage());
        echo json_encode(['status' => 'erro', 'mensagem' => 'Erro na base de dados: ' . $e->getMessage()]);
    }
}

/**
 * @brief Apaga um local (soft delete).
 * @param int $id ID do local a apagar
 * @return void
 */
function apagarLocal($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT criado_por, foto FROM locais WHERE id = ?");
        $stmt->execute([$id]);
        $local = $stmt->fetch();
        
        if (!$local) {
            echo json_encode(['status' => 'erro', 'mensagem' => 'Local não encontrado']);
            return;
        }
        
        // Verifica permissão
        if (!ehAdmin() && $local['criado_por'] != getUserId()) {
            echo json_encode(['status' => 'erro', 'mensagem' => 'Sem permissão para apagar este local']);
            return;
        }
        
        // Soft delete
        $stmt = $pdo->prepare("UPDATE locais SET ativo = 0 WHERE id = ?");
        $stmt->execute([$id]);
        
        // Apaga foto física
        if ($local['foto'] && file_exists(__DIR__ . '/../uploads/fotos/' . $local['foto'])) {
            unlink(__DIR__ . '/../uploads/fotos/' . $local['foto']);
        }
        
        echo json_encode(['status' => 'ok', 'mensagem' => 'Local apagado com sucesso']);
        
    } catch (PDOException $e) {
        error_log("Erro apagarLocal: " . $e->getMessage());
        echo json_encode(['status' => 'erro', 'mensagem' => 'Erro ao apagar local']);
    }
}
?>