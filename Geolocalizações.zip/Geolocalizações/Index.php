<?php
/**
 * @file index.php
 * @brief Página de autenticação do sistema.
 * 
 * Esta página apresenta o formulário de login e processa a
 * autenticação dos utilizadores, diferenciando entre admin
 * e utilizadores normais.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

/** @var string $erro Mensagem de erro de autenticação */
$erro = "";

/**
 * @brief Processa o formulário de login quando submetido via POST.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    /** @var string $email Email introduzido pelo utilizador */
    $email = $_POST['email'] ?? '';
    
    /** @var string $password Palavra-passe introduzida */
    $password = $_POST['password'] ?? '';
    
    try {
        /**
         * @var PDOStatement $stmt Prepared statement para buscar utilizador
         */
        $stmt = $pdo->prepare("
            SELECT id, email, senha, tipo, nome 
            FROM utilizadores 
            WHERE email = :email AND ativo = 1
        ");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        
        /**
         * @brief Valida credenciais e inicia sessão se corretas
         */
        if ($user && validarSenha($user['senha'], $password)) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['nome'] = $user['nome'];
            $_SESSION['tipo'] = $user['tipo'];
            $_SESSION['logado'] = true;
            
            header('Location: dashboard.php');
            exit;
        } else {
            $erro = "Email ou palavra-passe inválidos!";
        }
    } catch (PDOException $e) {
        $erro = "Erro no sistema. Tente novamente.";
    }
}

// Se já estiver logado, redireciona
if (estaLogado()) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Geolocalização</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gradient">
    <div class="container-fluid vh-100 d-flex align-items-center justify-content-center">
        <div class="card shadow-lg login-card p-4">
            <div class="text-center mb-4">
                <i class="bi bi-geo-alt-fill display-4 text-primary"></i>
                <h3 class="fw-bold mt-2">Sistema de Geolocalização</h3>
                <p class="text-muted small">Autenticação Segura</p>
            </div>

            <?php if ($erro): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= sanitizar($erro) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <form method="POST" action="index.php">
                <div class="form-floating mb-3">
                    <input type="email" name="email" class="form-control" id="email" placeholder="email@exemplo.com" required>
                    <label for="email"><i class="bi bi-envelope-fill me-2"></i>Email</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                    <label for="password"><i class="bi bi-lock-fill me-2"></i>Palavra-passe</label>
                </div>

                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-box-arrow-in-right me-2"></i>Entrar
                    </button>
                </div>
            </form>

            <div class="text-center small text-muted mt-3">
                © 2026 Sistema de Geolocalização
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>