<?php
/**
 * @file logout.php
 * @brief Script de terminação segura de sessão de utilizador.
 * 
 * Este ficheiro realiza o logout do utilizador de forma segura,
 * destruindo todos os dados da sessão, removendo cookies de sessão
 * e redirecionando para a página de login.
 * 
 * Inclui proteções contra:
 * - Session fixation attacks
 * - Session hijacking
 * - Cache de páginas protegidas no navegador
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @see includes/auth.php Para funções de autenticação
 * @note Este ficheiro não produz output HTML, apenas redireciona
 */

/**
 * @brief Inicia sessão se ainda não estiver ativa
 * 
 * Necessário para aceder e manipular variáveis de sessão
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * @brief Regista informação de logout para logs de segurança (opcional)
 * 
 * Em ambiente de produção, considere registar:
 * - Timestamp do logout
 * - IP do utilizador
 * - User agent
 */
$logout_info = [
    'timestamp' => date('Y-m-d H:i:s'),
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
    'user_id' => $_SESSION['user_id'] ?? null,
    'email' => $_SESSION['email'] ?? null
];

/**
 * @brief Limpa todas as variáveis de sessão
 * 
 * Remove todos os dados armazenados em $_SESSION
 */
$_SESSION = [];

/**
 * @brief Remove o cookie de sessão do navegador
 * 
 * Define expiração no passado para forçar eliminação
 */
if (isset($_COOKIE[session_name()])) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),           // Nome do cookie de sessão
        '',                       // Valor vazio
        [
            'expires' => time() - 3600,        // Expira há 1 hora
            'path' => $params['path'],         // Mesmo path
            'domain' => $params['domain'],     // Mesmo domínio
            'secure' => $params['secure'],     // Mesma flag secure
            'httponly' => $params['httponly'], // Mesma flag httponly
            'samesite' => 'Strict'             // Proteção CSRF
        ]
    );
}

/**
 * @brief Destrói a sessão no servidor
 * 
 * Elimina completamente os dados da sessão do servidor
 */
session_destroy();

/**
 * @brief Limpa headers de cache para prevenir acesso a páginas protegidas
 * 
 * Impede que o navegador mantenha em cache páginas protegidas
 * após o logout
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Data no passado

/**
 * @brief Redireciona para página de login com mensagem de confirmação
 * 
 * Opcionalmente pode passar mensagem via query string (não via sessão,
 * pois a sessão foi destruída)
 */
$redirect_url = 'index.php';

// Opcional: adicionar parâmetro de logout bem-sucedido
// $redirect_url .= '?logout=success';

header("Location: {$redirect_url}");
exit;