-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28-Fev-2026 às 00:47
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `geolocalizacao`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cor` varchar(7) DEFAULT '#4e73df',
  `letras` varchar(3) DEFAULT 'LOC',
  `icone` varchar(50) DEFAULT 'bi-geo-alt'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `cor`, `letras`, `icone`) VALUES
(1, 'Hospital', '#e74a3b', 'HSP', 'bi-geo-alt'),
(2, 'Aeroporto', '#4e73df', 'AER', 'bi-geo-alt'),
(3, 'Hotel', '#1cc88a', 'HTL', 'bi-geo-alt'),
(4, 'Restaurante', '#f6c23e', 'RST', 'bi-geo-alt'),
(5, 'Museu', '#36b9cc', 'MUS', 'bi-geo-alt'),
(6, 'Escola', '#6f42c1', 'ESC', 'bi-geo-alt'),
(7, 'Supermercado', '#fd7e14', 'SUP', 'bi-geo-alt');

-- --------------------------------------------------------

--
-- Estrutura da tabela `locais`
--

CREATE TABLE `locais` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `criado_por` int(11) NOT NULL,
  `pais` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `morada` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `locais`
--

INSERT INTO `locais` (`id`, `nome`, `categoria_id`, `criado_por`, `pais`, `cidade`, `morada`, `telefone`, `email`, `descricao`, `latitude`, `longitude`, `foto`, `ativo`, `criado_em`, `atualizado_em`) VALUES
(1, 'TIAGO ALVES', 2, 1, 'Portugal', 'Sesimbra', 'Rua dos Casais Ricos', '666666666', 'tiagoalves.22027@esec-sampaio.net', 'Oi amigo!', 38.44132932, -9.11391020, 'loc_69a2238c3fe566.39957331.gif', 1, '2026-02-27 23:06:52', '2026-02-27 23:06:52'),
(2, 'TIAGO ALVES', 1, 2, 'Portugal', 'Boticas', 'CM 1045', '33333333333333', 'tiagoalves.22027@esec-sampaio.net', 'sss', 41.62365539, -7.84423828, 'loc_69a2255a8ddb96.91234439.jpg', 1, '2026-02-27 23:14:34', '2026-02-27 23:14:34'),
(3, 'TIAGO ALVES', 4, 2, 'Portugal', 'Boticas', 'CM 1045', '666666666', 'tiagoalves.22027@esec-sampaio.net', 'rrrrr', 37.20408156, -7.00927734, 'loc_69a226f6ae9319.93289913.jpeg', 1, '2026-02-27 23:21:26', '2026-02-27 23:21:26');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizadores`
--

CREATE TABLE `utilizadores` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `tipo` enum('admin','utilizador') DEFAULT 'utilizador',
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `utilizadores`
--

INSERT INTO `utilizadores` (`id`, `nome`, `email`, `senha`, `tipo`, `ativo`, `criado_em`) VALUES
(1, 'Administrador', 'admin@geoloc.com', 'b227bff0d28823d4599a39a5b55725b0811c9c13184087e9a122eb572e6ff139', 'admin', 1, '2026-02-27 22:27:24'),
(2, 'Tiago Alves', 'user@geoloc.com', 'b227bff0d28823d4599a39a5b55725b0811c9c13184087e9a122eb572e6ff139', 'utilizador', 1, '2026-02-27 22:27:24'),
(3, 'Claudio', 'teste@gmail.com', 'b227bff0d28823d4599a39a5b55725b0811c9c13184087e9a122eb572e6ff139', 'utilizador', 1, '2026-02-27 23:16:23');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `locais`
--
ALTER TABLE `locais`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `criado_por` (`criado_por`);

--
-- Índices para tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `locais`
--
ALTER TABLE `locais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `locais`
--
ALTER TABLE `locais`
  ADD CONSTRAINT `locais_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`),
  ADD CONSTRAINT `locais_ibfk_2` FOREIGN KEY (`criado_por`) REFERENCES `utilizadores` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
