<?php
/**
 * @file categorias.php
 * @brief Página de gestão de categorias de locais.
 * 
 * Permite ao administrador criar, editar e apagar categorias.
 * Cada categoria tem uma cor, sigla e ícone associados para
 * identificação visual no mapa.
 * 
 * @author Sistema de Geolocalização
 * @date 2026
 * 
 * @note Apenas administradores têm acesso a esta página
 */

require_once __DIR__ . '/includes/auth.php';
requerAutenticacao();

// Verifica se é admin
if (!ehAdmin()) {
    $_SESSION['mensagem'] = 'Acesso restrito a administradores.';
    $_SESSION['mensagem_tipo'] = 'danger';
    header('Location: dashboard.php');
    exit;
}

require_once __DIR__ . '/includes/functions.php';

/** @var string $modo Modo atual da página ('listar', 'criar', 'editar') */
$modo = $_GET['modo'] ?? 'listar';

/** @var int|null $edit_id ID da categoria em edição */
$edit_id = isset($_GET['id']) ? (int)$_GET['id'] : null;

/** @var array $erros Array de erros de validação */
$erros = [];

/** @var array $dados Dados do formulário */
$dados = [
    'nome' => '',
    'cor' => '#4e73df',
    'letras' => '',
    'icone' => 'bi-geo-alt'
];

/**
 * @brief Processa formulário de criação/edição
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    /** @var string $acao Ação do formulário (criar|atualizar) */
    $acao = $_POST['acao'] ?? '';
    
    // Validação dos dados
    $dados['nome'] = trim($_POST['nome'] ?? '');
    $dados['cor'] = trim($_POST['cor'] ?? '#4e73df');
    $dados['letras'] = strtoupper(trim($_POST['letras'] ?? ''));
    $dados['icone'] = trim($_POST['icone'] ?? 'bi-geo-alt');
    
    if (empty($dados['nome'])) {
        $erros[] = 'O nome da categoria é obrigatório.';
    }
    
    if (strlen($dados['letras']) > 3) {
        $erros[] = 'A sigla deve ter no máximo 3 caracteres.';
    }
    
    // Validação da cor (formato hexadecimal)
    if (!preg_match('/^#[a-fA-F0-9]{6}$/', $dados['cor'])) {
        $erros[] = 'Cor inválida. Use formato hexadecimal (ex: #4e73df).';
    }
    
    if (empty($erros)) {
        try {
            if ($acao === 'criar') {
                // Verifica se nome já existe
                $stmt = $pdo->prepare("SELECT id FROM categorias WHERE nome = ?");
                $stmt->execute([$dados['nome']]);
                if ($stmt->fetch()) {
                    $erros[] = 'Já existe uma categoria com este nome.';
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO categorias (nome, cor, letras, icone) 
                        VALUES (:nome, :cor, :letras, :icone)
                    ");
                    $stmt->execute($dados);
                    
                    $_SESSION['mensagem'] = 'Categoria criada com sucesso!';
                    $_SESSION['mensagem_tipo'] = 'success';
                    header('Location: categorias.php');
                    exit;
                }
            } elseif ($acao === 'atualizar' && $edit_id) {
                // Verifica se nome já existe noutra categoria
                $stmt = $pdo->prepare("SELECT id FROM categorias WHERE nome = ? AND id != ?");
                $stmt->execute([$dados['nome'], $edit_id]);
                if ($stmt->fetch()) {
                    $erros[] = 'Já existe outra categoria com este nome.';
                } else {
                    $dados['id'] = $edit_id;
                    $stmt = $pdo->prepare("
                        UPDATE categorias 
                        SET nome = :nome, cor = :cor, letras = :letras, icone = :icone 
                        WHERE id = :id
                    ");
                    $stmt->execute($dados);
                    
                    $_SESSION['mensagem'] = 'Categoria atualizada com sucesso!';
                    $_SESSION['mensagem_tipo'] = 'success';
                    header('Location: categorias.php');
                    exit;
                }
            }
        } catch (PDOException $e) {
            $erros[] = 'Erro na base de dados: ' . $e->getMessage();
        }
    }
}

/**
 * @brief Processa pedido de eliminação
 */
if ($modo === 'apagar' && $edit_id) {
    try {
        // Verifica se existem locais usando esta categoria
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM locais WHERE categoria_id = ? AND ativo = 1");
        $stmt->execute([$edit_id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $_SESSION['mensagem'] = "Não é possível apagar: existem {$count} locais usando esta categoria.";
            $_SESSION['mensagem_tipo'] = 'danger';
        } else {
            $stmt = $pdo->prepare("DELETE FROM categorias WHERE id = ?");
            $stmt->execute([$edit_id]);
            
            $_SESSION['mensagem'] = 'Categoria apagada com sucesso!';
            $_SESSION['mensagem_tipo'] = 'success';
        }
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = 'Erro ao apagar categoria.';
        $_SESSION['mensagem_tipo'] = 'danger';
    }
    
    header('Location: categorias.php');
    exit;
}

/**
 * @brief Carrega dados para edição
 */
if ($modo === 'editar' && $edit_id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM categorias WHERE id = ?");
        $stmt->execute([$edit_id]);
        $categoria = $stmt->fetch();
        
        if ($categoria) {
            $dados = $categoria;
        } else {
            $_SESSION['mensagem'] = 'Categoria não encontrada.';
            $_SESSION['mensagem_tipo'] = 'danger';
            header('Location: categorias.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = 'Erro ao carregar categoria.';
        $_SESSION['mensagem_tipo'] = 'danger';
        header('Location: categorias.php');
        exit;
    }
}

/**
 * @brief Busca todas as categorias para listagem
 */
try {
    $stmt = $pdo->query("SELECT c.*, COUNT(l.id) as total_locais 
                         FROM categorias c 
                         LEFT JOIN locais l ON c.id = l.categoria_id AND l.ativo = 1 
                         GROUP BY c.id 
                         ORDER BY c.nome");
    $categorias = $stmt->fetchAll();
} catch (PDOException $e) {
    $categorias = [];
    $erros[] = 'Erro ao carregar categorias.';
}

// Configuração do template
$titulo_pagina = 'Gestão de Categorias';
$breadcrumb = [
    ['url' => 'dashboard.php', 'texto' => 'Dashboard'],
    ['texto' => 'Categorias']
];

include __DIR__ . '/templates/header.php';
?>

<!-- Cabeçalho da página -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-0"><i class="bi bi-tags-fill text-primary"></i> Gestão de Categorias</h2>
        <p class="text-muted mb-0">Configure as categorias disponíveis para classificação de locais</p>
    </div>
    
    <?php if ($modo === 'listar'): ?>
    <a href="categorias.php?modo=criar" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nova Categoria
    </a>
    <?php else: ?>
    <a href="categorias.php" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Voltar à Lista
    </a>
    <?php endif; ?>
</div>

<?php if (!empty($erros)): ?>
<div class="alert alert-danger">
    <h6><i class="bi bi-exclamation-triangle-fill"></i> Erros encontrados:</h6>
    <ul class="mb-0">
        <?php foreach ($erros as $erro): ?>
        <li><?= sanitizar($erro) ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<?php if ($modo === 'listar'): ?>
<!-- Listagem de Categorias -->
<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Visual</th>
                        <th>Nome</th>
                        <th>Sigla</th>
                        <th>Ícone</th>
                        <th>Locais</th>
                        <th class="text-end">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categorias as $cat): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <div style="width: 30px; height: 30px; background: <?= $cat['cor'] ?>; 
                                            border-radius: 5px; display: flex; align-items: center; 
                                            justify-content: center; color: white; font-weight: bold;
                                            font-size: 12px; margin-right: 10px;">
                                    <?= sanitizar($cat['letras']) ?>
                                </div>
                                <code><?= sanitizar($cat['cor']) ?></code>
                            </div>
                        </td>
                        <td><strong><?= sanitizar($cat['nome']) ?></strong></td>
                        <td><span class="badge bg-secondary"><?= sanitizar($cat['letras']) ?></span></td>
                        <td><i class="bi <?= sanitizar($cat['icone']) ?> fs-5"></i> <small class="text-muted"><?= sanitizar($cat['icone']) ?></small></td>
                        <td>
                            <span class="badge bg-info"><?= $cat['total_locais'] ?> locais</span>
                        </td>
                        <td class="text-end">
                            <a href="categorias.php?modo=editar&id=<?= $cat['id'] ?>" 
                               class="btn btn-sm btn-outline-warning" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <?php if ($cat['total_locais'] == 0): ?>
                            <a href="categorias.php?modo=apagar&id=<?= $cat['id'] ?>" 
                               class="btn btn-sm btn-outline-danger" 
                               onclick="return confirm('Tem certeza que deseja apagar esta categoria?')"
                               title="Apagar">
                                <i class="bi bi-trash"></i>
                            </a>
                            <?php else: ?>
                            <button class="btn btn-sm btn-outline-secondary" disabled title="Não pode apagar: existem locais associados">
                                <i class="bi bi-trash"></i>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($categorias)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                            Nenhuma categoria encontrada.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Preview de como ficam os marcadores -->
<div class="card mt-4 shadow-sm">
    <div class="card-header bg-light">
        <h5 class="mb-0"><i class="bi bi-eye"></i> Pré-visualização dos Marcadores</h5>
    </div>
    <div class="card-body">
        <div class="d-flex flex-wrap gap-3">
            <?php foreach ($categorias as $cat): ?>
            <div class="text-center">
                <div style="position: relative; width: 30px; height: 42px; margin: 0 auto;">
                    <svg viewBox="0 0 30 42" width="30" height="42">
                        <path d="M15 0 C23 0 30 7 30 15 C30 23 15 42 15 42 C15 42 0 23 0 15 C0 7 7 0 15 0 Z" 
                              fill="<?= $cat['cor'] ?>" stroke="#fff" stroke-width="2"/>
                    </svg>
                    <div style="position: absolute; top: 6px; left: 6px; width: 18px; height: 18px; 
                                background: white; border-radius: 50%; text-align: center; 
                                line-height: 18px; font-size: 10px; font-weight: bold;">
                        <?= sanitizar($cat['letras']) ?>
                    </div>
                </div>
                <small class="d-block mt-1 text-muted" style="font-size: 10px;"><?= sanitizar($cat['nome']) ?></small>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php else: ?>
<!-- Formulário Criar/Editar -->
<div class="card shadow-sm">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">
            <i class="bi bi-<?= $modo === 'criar' ? 'plus-lg' : 'pencil' ?>"></i>
            <?= $modo === 'criar' ? 'Nova Categoria' : 'Editar Categoria' ?>
        </h5>
    </div>
    <div class="card-body">
        <form method="POST" action="categorias.php<?= $modo === 'editar' ? '?modo=editar&id=' . $edit_id : '' ?>">
            <input type="hidden" name="acao" value="<?= $modo ?>">
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nome" class="form-label">Nome da Categoria *</label>
                    <input type="text" class="form-control" id="nome" name="nome" 
                           value="<?= sanitizar($dados['nome']) ?>" required maxlength="50">
                    <div class="form-text">Ex: Hospital, Aeroporto, Hotel...</div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="letras" class="form-label">Sigla/Abreviatura *</label>
                    <input type="text" class="form-control" id="letras" name="letras" 
                           value="<?= sanitizar($dados['letras']) ?>" required maxlength="3">
                    <div class="form-text">Máximo 3 letras. Ex: HSP, AER, HTL...</div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="cor" class="form-label">Cor do Marcador *</label>
                    <div class="input-group">
                        <input type="color" class="form-control form-control-color" id="cor" name="cor" 
                               value="<?= sanitizar($dados['cor']) ?>" required style="max-width: 60px;">
                        <input type="text" class="form-control" id="cor_texto" 
                               value="<?= sanitizar($dados['cor']) ?>" maxlength="7">
                    </div>
                    <div class="form-text">Escolha uma cor para identificar a categoria no mapa</div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="icone" class="form-label">Ícone Bootstrap *</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-<?= sanitizar($dados['icone']) ?>" id="preview_icone"></i></span>
                        <select class="form-select" id="icone" name="icone" required>
                            <?php 
                            $icones = ['geo-alt', 'hospital', 'airplane', 'building', 'shop', 'bank', 'cup-hot', 
                                      'tree', 'bus-front', 'train-front', 'anchor', 'balloon', 'camera', 'clock',
                                      'envelope', 'flag', 'gift', 'house', 'info-circle', 'journal', 'key'];
                            foreach ($icones as $ico): 
                            ?>
                            <option value="bi-<?= $ico ?>" <?= $dados['icone'] === 'bi-' . $ico ? 'selected' : '' ?>>
                                <?= ucfirst($ico) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-text">Ícone usado nas listagens e menus</div>
                </div>
            </div>
            
            <!-- Preview ao vivo -->
            <div class="mb-3">
                <label class="form-label">Pré-visualização do Marcador</label>
                <div class="p-3 bg-light rounded border text-center">
                    <div id="preview_marcador" style="display: inline-block;">
                        <div style="position: relative; width: 40px; height: 56px;">
                            <svg viewBox="0 0 30 42" width="40" height="56">
                                <path d="M15 0 C23 0 30 7 30 15 C30 23 15 42 15 42 C15 42 0 23 0 15 C0 7 7 0 15 0 Z" 
                                      fill="<?= $dados['cor'] ?>" stroke="#fff" stroke-width="2"/>
                            </svg>
                            <div id="preview_letras" style="position: absolute; top: 8px; left: 8px; width: 24px; 
                                                           height: 24px; background: white; border-radius: 50%; 
                                                           text-align: center; line-height: 24px; font-size: 12px; 
                                                           font-weight: bold;">
                                <?= sanitizar($dados['letras']) ?>
                            </div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <strong id="preview_nome"><?= sanitizar($dados['nome']) ?></strong>
                    </div>
                </div>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg"></i> <?= $modo === 'criar' ? 'Criar Categoria' : 'Guardar Alterações' ?>
                </button>
                <a href="categorias.php" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
/**
 * @brief Atualiza preview ao vivo do marcador
 */
document.addEventListener('DOMContentLoaded', function() {
    const inputs = {
        nome: document.getElementById('nome'),
        letras: document.getElementById('letras'),
        cor: document.getElementById('cor'),
        cor_texto: document.getElementById('cor_texto'),
        icone: document.getElementById('icone')
    };
    
    const previews = {
        nome: document.getElementById('preview_nome'),
        letras: document.getElementById('preview_letras'),
        marcador: document.querySelector('#preview_marcador svg path'),
        icone: document.getElementById('preview_icone')
    };
    
    // Atualiza preview do nome
    inputs.nome.addEventListener('input', function() {
        previews.nome.textContent = this.value || 'Nome da Categoria';
    });
    
    // Atualiza preview das letras
    inputs.letras.addEventListener('input', function() {
        previews.letras.textContent = this.value.toUpperCase();
    });
    
    // Atualiza preview da cor
    inputs.cor.addEventListener('input', function() {
        previews.marcador.setAttribute('fill', this.value);
        inputs.cor_texto.value = this.value;
    });
    
    inputs.cor_texto.addEventListener('input', function() {
        if (/^#[a-fA-F0-9]{6}$/.test(this.value)) {
            inputs.cor.value = this.value;
            previews.marcador.setAttribute('fill', this.value);
        }
    });
    
    // Atualiza preview do ícone
    inputs.icone.addEventListener('change', function() {
        previews.icone.className = 'bi ' + this.value;
    });
});
</script>

<?php endif; ?>

<?php include __DIR__ . '/templates/footer.php'; ?>